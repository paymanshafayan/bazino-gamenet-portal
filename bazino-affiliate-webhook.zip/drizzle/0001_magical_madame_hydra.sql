CREATE TABLE `affiliateReferrals` (
	`id` int AUTO_INCREMENT NOT NULL,
	`campaignId` varchar(64) NOT NULL,
	`mediaId` varchar(191) NOT NULL,
	`partnerIgUserId` varchar(191) NOT NULL,
	`partnerUsername` varchar(191),
	`partnerCode` varchar(64) NOT NULL,
	`inviteUrl` text NOT NULL,
	`partnerCommentId` varchar(191) NOT NULL,
	`language` varchar(10) NOT NULL DEFAULT 'fa',
	`portalIsNew` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `affiliateReferrals_id` PRIMARY KEY(`id`),
	CONSTRAINT `affiliateReferrals_partnerCampaign_uq` UNIQUE(`partnerIgUserId`,`campaignId`)
);
--> statement-breakpoint
CREATE TABLE `friendCodeEvents` (
	`id` int AUTO_INCREMENT NOT NULL,
	`commentId` varchar(191) NOT NULL,
	`mediaId` varchar(191) NOT NULL,
	`partnerCode` varchar(64) NOT NULL,
	`friendIgUserId` varchar(191) NOT NULL,
	`friendUsername` varchar(191),
	`verificationMethod` varchar(80) NOT NULL DEFAULT 'share_confirmed_by_friend_code',
	`status` varchar(40) NOT NULL DEFAULT 'received',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `friendCodeEvents_id` PRIMARY KEY(`id`),
	CONSTRAINT `friendCodeEvents_comment_uq` UNIQUE(`commentId`)
);
--> statement-breakpoint
CREATE TABLE `messageEvents` (
	`id` int AUTO_INCREMENT NOT NULL,
	`recipientIgUserId` varchar(191) NOT NULL,
	`commentId` varchar(191) NOT NULL,
	`messageType` varchar(40) NOT NULL,
	`providerMessageId` varchar(191),
	`status` varchar(40) NOT NULL,
	`errorCode` varchar(100),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `messageEvents_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `webhookEvents` (
	`id` int AUTO_INCREMENT NOT NULL,
	`providerEventId` varchar(191) NOT NULL,
	`eventType` varchar(100) NOT NULL,
	`payloadHash` varchar(64) NOT NULL,
	`rawPayload` text NOT NULL,
	`status` varchar(40) NOT NULL DEFAULT 'received',
	`errorCode` varchar(100),
	`receivedAt` timestamp NOT NULL DEFAULT (now()),
	`processedAt` timestamp,
	CONSTRAINT `webhookEvents_id` PRIMARY KEY(`id`),
	CONSTRAINT `webhookEvents_providerEventId_uq` UNIQUE(`providerEventId`)
);
