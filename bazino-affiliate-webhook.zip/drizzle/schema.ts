import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, uniqueIndex } from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export const webhookEvents = mysqlTable(
  "webhookEvents",
  {
    id: int("id").autoincrement().primaryKey(),
    providerEventId: varchar("providerEventId", { length: 191 }).notNull(),
    eventType: varchar("eventType", { length: 100 }).notNull(),
    payloadHash: varchar("payloadHash", { length: 64 }).notNull(),
    rawPayload: text("rawPayload").notNull(),
    status: varchar("status", { length: 40 }).notNull().default("received"),
    errorCode: varchar("errorCode", { length: 100 }),
    receivedAt: timestamp("receivedAt").defaultNow().notNull(),
    processedAt: timestamp("processedAt"),
  },
  table => ({ providerEventUnique: uniqueIndex("webhookEvents_providerEventId_uq").on(table.providerEventId) }),
);

export const affiliateReferrals = mysqlTable(
  "affiliateReferrals",
  {
    id: int("id").autoincrement().primaryKey(),
    campaignId: varchar("campaignId", { length: 64 }).notNull(),
    mediaId: varchar("mediaId", { length: 191 }).notNull(),
    partnerIgUserId: varchar("partnerIgUserId", { length: 191 }).notNull(),
    partnerUsername: varchar("partnerUsername", { length: 191 }),
    partnerCode: varchar("partnerCode", { length: 64 }).notNull(),
    inviteUrl: text("inviteUrl").notNull(),
    partnerCommentId: varchar("partnerCommentId", { length: 191 }).notNull(),
    language: varchar("language", { length: 10 }).notNull().default("fa"),
    portalIsNew: int("portalIsNew").notNull().default(0),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => ({ partnerCampaignUnique: uniqueIndex("affiliateReferrals_partnerCampaign_uq").on(table.partnerIgUserId, table.campaignId) }),
);

export const friendCodeEvents = mysqlTable(
  "friendCodeEvents",
  {
    id: int("id").autoincrement().primaryKey(),
    commentId: varchar("commentId", { length: 191 }).notNull(),
    mediaId: varchar("mediaId", { length: 191 }).notNull(),
    partnerCode: varchar("partnerCode", { length: 64 }).notNull(),
    friendIgUserId: varchar("friendIgUserId", { length: 191 }).notNull(),
    friendUsername: varchar("friendUsername", { length: 191 }),
    verificationMethod: varchar("verificationMethod", { length: 80 }).notNull().default("share_confirmed_by_friend_code"),
    status: varchar("status", { length: 40 }).notNull().default("received"),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  table => ({ commentUnique: uniqueIndex("friendCodeEvents_comment_uq").on(table.commentId) }),
);

export const messageEvents = mysqlTable("messageEvents", {
  id: int("id").autoincrement().primaryKey(),
  recipientIgUserId: varchar("recipientIgUserId", { length: 191 }).notNull(),
  commentId: varchar("commentId", { length: 191 }).notNull(),
  messageType: varchar("messageType", { length: 40 }).notNull(),
  providerMessageId: varchar("providerMessageId", { length: 191 }),
  status: varchar("status", { length: 40 }).notNull(),
  errorCode: varchar("errorCode", { length: 100 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type AffiliateReferral = typeof affiliateReferrals.$inferSelect;
