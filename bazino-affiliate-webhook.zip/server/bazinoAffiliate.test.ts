import { createHmac } from "node:crypto";
import { describe, expect, it, beforeEach } from "vitest";
import {
  buildFriendMessage,
  buildPartnerMessage,
  extractFriendCode,
  isPartnerKeyword,
  normalizeCommentEvent,
  verifyZernioSignature,
} from "./bazinoAffiliate";

describe("Bazino affiliate webhook rules", () => {
  beforeEach(() => {
    process.env.ZERNIO_WEBHOOK_SECRET = "test-secret";
  });

  it("matches only the approved Persian keyword", () => {
    expect(isPartnerKeyword("آماده")).toBe(true);
    expect(isPartnerKeyword(" آماده ")).toBe(true);
    expect(isPartnerKeyword("آماده‌ای؟")).toBe(false);
    expect(isPartnerKeyword("Ready")).toBe(false);
  });

  it("extracts numeric friend codes only", () => {
    expect(extractFriendCode("482913")).toBe("482913");
    expect(extractFriendCode(" 482913 ")).toBe("482913");
    expect(extractFriendCode("code 482913")).toBeNull();
  });

  it("preserves the approved partner message shape and excludes the invite URL", () => {
    const message = buildPartnerMessage("482913");
    expect(message).toContain("482913");
    expect(message).toContain("@bazinopro");
    expect(message).not.toContain("https://bazino.pro");
  });

  it("sends the portal invite URL only in the friend message", () => {
    const message = buildFriendMessage("https://bazino.pro/?ref=482913");
    expect(message).toContain("https://bazino.pro/?ref=482913");
  });

  it("verifies the X-Zernio-Signature HMAC", () => {
    const body = Buffer.from('{"id":"event-1"}');
    const signature = createHmac("sha256", "test-secret").update(body).digest("hex");
    expect(verifyZernioSignature(body, `sha256=${signature}`)).toBe(true);
    expect(verifyZernioSignature(body, "sha256=bad")).toBe(false);
  });

  it("normalizes a comment event without treating media id as user id", () => {
    const event = normalizeCommentEvent({
      id: "event-1",
      event: "comment.received",
      accountId: "6a9488fe77555aae011b7a18",
      data: {
        mediaId: "18109137383324992",
        commentId: "comment-1",
        text: "آماده",
        author: { id: "17841400000000001", username: "partner" },
      },
    }, "fallback");
    expect(event).toMatchObject({
      eventId: "event-1",
      postId: "18109137383324992",
      commentId: "comment-1",
      igUserId: "17841400000000001",
    });
  });
});
