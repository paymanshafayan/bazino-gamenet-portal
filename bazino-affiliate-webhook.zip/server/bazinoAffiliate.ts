import crypto from "node:crypto";

export const CAMPAIGN_ID = "SQUAD26";
export const TEST_MEDIA_ID = "18109137383324992";
export const PORTAL_INVITE_ENDPOINT =
  "https://bazino.pro/api/integrations/instagram/partner-invite";

export type PartnerInvite = {
  ok: boolean;
  code: string;
  invite_url: string;
  campaign: string;
  is_new: boolean;
};

export type PrivateReplyInput = {
  postId: string;
  commentId: string;
  message: string;
};

function requireEnv(name: string): string {
  const value = process.env[name];
  if (!value) throw new Error(`Missing required environment variable: ${name}`);
  return value;
}

export function normalizeCommentText(value: unknown): string {
  return typeof value === "string" ? value.trim() : "";
}

export function isPartnerKeyword(text: string): boolean {
  return normalizeCommentText(text) === "آماده";
}

export function extractFriendCode(text: string): string | null {
  const normalized = normalizeCommentText(text);
  return /^\d{3,32}$/.test(normalized) ? normalized : null;
}

export function buildPartnerMessage(code: string): string {
  return `این کد: ${code} را زیر پستی که برایت فرستادم کامنت کن و پیج @bazinopro را Follow کن. پس از تکمیل مراحل کمپین، یک لینک دعوت برایت ارسال میشود. روی لینک بزن تا در صورت تکمیل مراحل، یک کوپن تخفیف عالی دریافت می کنی. ممنون میشوم اگر این کار را برایم انجام بدهی.`;
}

export function buildFriendMessage(inviteUrl: string): string {
  return `لینک دعوت بازینو برایت آماده است: ${inviteUrl}`;
}

export async function mintPartnerInvite(input: {
  igUserId: string;
  igUsername?: string;
}): Promise<PartnerInvite> {
  const response = await fetch(PORTAL_INVITE_ENDPOINT, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${requireEnv("BAZINO_PORTAL_API_TOKEN")}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      ig_user_id: input.igUserId,
      ...(input.igUsername ? { ig_username: input.igUsername } : {}),
      campaign_id: CAMPAIGN_ID,
    }),
  });

  if (response.status === 401) throw new Error("PORTAL_TOKEN_INVALID");
  if (response.status === 400) throw new Error("INVALID_INSTAGRAM_ACCOUNT_ID");
  if (response.status === 422) throw new Error("CAMPAIGN_NOT_FOUND");
  if (!response.ok) throw new Error(`PORTAL_HTTP_${response.status}`);

  const result = (await response.json()) as Partial<PartnerInvite>;
  if (!result.ok || !result.code || !result.invite_url) {
    throw new Error("INVALID_PORTAL_RESPONSE");
  }

  return {
    ok: true,
    code: result.code,
    invite_url: result.invite_url,
    campaign: result.campaign ?? CAMPAIGN_ID,
    is_new: Boolean(result.is_new),
  };
}

export async function sendPrivateReply(input: PrivateReplyInput): Promise<unknown> {
  const accountId = requireEnv("ZERNIO_ACCOUNT_ID");
  const endpoint = `https://zernio.com/api/v1/inbox/comments/${encodeURIComponent(input.postId)}/${encodeURIComponent(input.commentId)}/private-reply`;
  const response = await fetch(endpoint, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${requireEnv("ZERNIO_API_KEY")}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ accountId, message: input.message }),
  });

  if (!response.ok) {
    const body = await response.text();
    throw new Error(`ZERNIO_PRIVATE_REPLY_${response.status}:${body.slice(0, 500)}`);
  }

  return response.json();
}

export function verifyZernioSignature(rawBody: Buffer, signature: string | undefined): boolean {
  const secret = process.env.ZERNIO_WEBHOOK_SECRET;
  if (!secret || !signature) return false;
  const digest = crypto.createHmac("sha256", secret).update(rawBody).digest("hex");
  const supplied = signature.startsWith("sha256=") ? signature.slice(7) : signature;
  const expected = Buffer.from(digest, "utf8");
  const actual = Buffer.from(supplied, "utf8");
  return expected.length === actual.length && crypto.timingSafeEqual(expected, actual);
}

export function hashPayload(rawBody: Buffer): string {
  return crypto.createHash("sha256").update(rawBody).digest("hex");
}

export type NormalizedComment = {
  eventId: string;
  eventType: string;
  accountId: string;
  postId: string;
  commentId: string;
  text: string;
  igUserId: string;
  igUsername?: string;
};

function firstString(...values: unknown[]): string {
  return values.find((value): value is string => typeof value === "string" && value.length > 0) ?? "";
}

export function normalizeCommentEvent(payload: any, fallbackEventId: string): NormalizedComment | null {
  const data = payload?.data ?? payload?.payload ?? payload;
  const comment = data?.comment ?? data?.commentData ?? {};
  const author = comment?.author ?? data?.author ?? data?.sender ?? data?.from ?? {};
  const eventType = firstString(payload?.event, payload?.type, payload?.eventType, "comment.received");
  if (!eventType.toLowerCase().includes("comment")) return null;

  const postId = firstString(
    data?.postId,
    data?.mediaId,
    data?.platformPostId,
    comment?.postId,
    comment?.mediaId,
    payload?.platformPostId,
  );
  const commentId = firstString(data?.commentId, comment?.id, data?.id, payload?.commentId);
  const text = firstString(data?.text, data?.commentText, comment?.text, comment?.message);
  const igUserId = firstString(author?.id, author?.userId, author?.igUserId, data?.igUserId);
  const igUsername = firstString(author?.username, author?.userName, data?.username, data?.igUsername) || undefined;
  const accountId = firstString(data?.accountId, payload?.accountId);

  if (!postId || !commentId || !text || !igUserId) return null;
  return { eventId: firstString(payload?.id, payload?.eventId, fallbackEventId), eventType, accountId, postId, commentId, text, igUserId, igUsername };
}

export function isNumericInstagramUserId(value: string): boolean {
  return /^\d+$/.test(value);
}
