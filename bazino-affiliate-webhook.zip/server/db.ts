import { and, eq } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  affiliateReferrals,
  friendCodeEvents,
  InsertUser,
  messageEvents,
  User,
  users,
  webhookEvents,
} from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) return;

  const values: InsertUser = { openId: user.openId };
  const updateSet: Record<string, unknown> = {};
  const textFields = ["name", "email", "loginMethod"] as const;
  for (const field of textFields) {
    if (user[field] !== undefined) {
      values[field] = user[field] ?? null;
      updateSet[field] = user[field] ?? null;
    }
  }
  values.lastSignedIn = user.lastSignedIn ?? new Date();
  updateSet.lastSignedIn = values.lastSignedIn;
  if (user.role !== undefined || user.openId === ENV.ownerOpenId) {
    values.role = user.role ?? "admin";
    updateSet.role = values.role;
  }
  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string): Promise<User | undefined> {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result[0];
}

export async function hasWebhookEvent(providerEventId: string): Promise<boolean> {
  const db = await getDb();
  if (!db) return false;
  const result = await db.select({ id: webhookEvents.id }).from(webhookEvents).where(eq(webhookEvents.providerEventId, providerEventId)).limit(1);
  return result.length > 0;
}

export async function insertWebhookEvent(input: {
  providerEventId: string;
  eventType: string;
  payloadHash: string;
  rawPayload: string;
}) {
  const db = await getDb();
  if (!db) return null;
  const existing = await db.select().from(webhookEvents).where(eq(webhookEvents.providerEventId, input.providerEventId)).limit(1);
  if (existing[0]) return existing[0];
  await db.insert(webhookEvents).values(input);
  const rows = await db.select().from(webhookEvents).where(eq(webhookEvents.providerEventId, input.providerEventId)).limit(1);
  return rows[0] ?? null;
}

export async function markWebhookEvent(providerEventId: string, status: string, errorCode?: string) {
  const db = await getDb();
  if (!db) return;
  await db.update(webhookEvents).set({ status, errorCode, processedAt: new Date() }).where(eq(webhookEvents.providerEventId, providerEventId));
}

export async function getReferralByPartner(partnerIgUserId: string, campaignId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const rows = await db.select().from(affiliateReferrals).where(and(eq(affiliateReferrals.partnerIgUserId, partnerIgUserId), eq(affiliateReferrals.campaignId, campaignId))).limit(1);
  return rows[0];
}

export async function getReferralByCode(partnerCode: string, mediaId: string, campaignId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const rows = await db.select().from(affiliateReferrals).where(and(eq(affiliateReferrals.partnerCode, partnerCode), eq(affiliateReferrals.mediaId, mediaId), eq(affiliateReferrals.campaignId, campaignId))).limit(1);
  return rows[0];
}

export async function insertReferral(input: typeof affiliateReferrals.$inferInsert) {
  const db = await getDb();
  if (!db) return null;
  await db.insert(affiliateReferrals).values(input).onDuplicateKeyUpdate({
    set: { partnerCode: input.partnerCode, inviteUrl: input.inviteUrl, updatedAt: new Date() },
  });
  const rows = await db.select().from(affiliateReferrals).where(and(eq(affiliateReferrals.partnerIgUserId, input.partnerIgUserId), eq(affiliateReferrals.campaignId, input.campaignId))).limit(1);
  return rows[0] ?? null;
}

export async function insertFriendCodeEvent(input: typeof friendCodeEvents.$inferInsert) {
  const db = await getDb();
  if (!db) return null;
  await db.insert(friendCodeEvents).values(input).onDuplicateKeyUpdate({ set: { status: "duplicate" } });
  return true;
}

export async function insertMessageEvent(input: typeof messageEvents.$inferInsert) {
  const db = await getDb();
  if (!db) return null;
  await db.insert(messageEvents).values(input);
  return true;
}

export async function hasMessageForComment(commentId: string, messageType: string): Promise<boolean> {
  const db = await getDb();
  if (!db) return false;
  const rows = await db.select({ id: messageEvents.id }).from(messageEvents).where(and(eq(messageEvents.commentId, commentId), eq(messageEvents.messageType, messageType))).limit(1);
  return rows.length > 0;
}
