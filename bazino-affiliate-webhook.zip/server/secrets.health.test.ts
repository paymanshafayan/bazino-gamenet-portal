import { describe, expect, it } from "vitest";

describe("configured Zernio secret", () => {
  it("authenticates against the read-only automations endpoint", async () => {
    const apiKey = process.env.ZERNIO_API_KEY;
    expect(apiKey, "ZERNIO_API_KEY must be configured").toBeTruthy();
    const response = await fetch("https://zernio.com/api/v1/comment-automations", {
      headers: { Authorization: `Bearer ${apiKey}` },
    });
    expect(response.status).toBe(200);
  }, 30_000);
});
