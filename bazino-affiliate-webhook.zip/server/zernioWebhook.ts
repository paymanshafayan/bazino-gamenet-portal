import type { Express, Request, Response } from "express";
import { ENV } from "./_core/env";
import {
  buildFriendMessage,
  buildPartnerMessage,
  extractFriendCode,
  hashPayload,
  isNumericInstagramUserId,
  isPartnerKeyword,
  mintPartnerInvite,
  normalizeCommentEvent,
  sendPrivateReply,
  TEST_MEDIA_ID,
  verifyZernioSignature,
} from "./bazinoAffiliate";
import {
  getReferralByCode,
  getReferralByPartner,
  hasMessageForComment,
  insertFriendCodeEvent,
  insertMessageEvent,
  insertReferral,
  insertWebhookEvent,
  markWebhookEvent,
} from "./db";

function getRawBody(req: Request): Buffer {
  const rawBody = (req as Request & { rawBody?: Buffer }).rawBody;
  return rawBody ?? Buffer.from(JSON.stringify(req.body ?? {}));
}

function sendJson(res: Response, status: number, body: Record<string, unknown>) {
  return res.status(status).json(body);
}

async function handleCommentEvent(req: Request): Promise<{ status: number; body: Record<string, unknown> }> {
  const rawBody = getRawBody(req);
  const eventIdFallback = hashPayload(rawBody);
  const normalized = normalizeCommentEvent(req.body, eventIdFallback);
  if (!normalized) return { status: 200, body: { ok: true, ignored: "unsupported_event" } };

  if (normalized.accountId && normalized.accountId !== ENV.zernioAccountId) {
    return { status: 200, body: { ok: true, ignored: "account_mismatch" } };
  }
  if (normalized.postId !== ENV.testMediaId && normalized.postId !== TEST_MEDIA_ID) {
    return { status: 200, body: { ok: true, ignored: "media_not_in_scope" } };
  }

  const storedEvent = await insertWebhookEvent({
    providerEventId: normalized.eventId,
    eventType: normalized.eventType,
    payloadHash: hashPayload(rawBody),
    rawPayload: rawBody.toString("utf8"),
  });
  if (storedEvent && ["processed", "ignored"].includes(storedEvent.status)) {
    return { status: 200, body: { ok: true, duplicate: true, eventId: normalized.eventId } };
  }

  try {
    if (isPartnerKeyword(normalized.text)) {
      if (!isNumericInstagramUserId(normalized.igUserId)) {
        await markWebhookEvent(normalized.eventId, "failed", "missing_numeric_ig_user_id");
        return { status: 422, body: { ok: false, error: "missing_numeric_ig_user_id" } };
      }
      if (await hasMessageForComment(normalized.commentId, "partner_code")) {
        await markWebhookEvent(normalized.eventId, "processed");
        return { status: 200, body: { ok: true, duplicate: true, reason: "partner_message_already_sent" } };
      }

      let referral = await getReferralByPartner(normalized.igUserId, ENV.campaignId);
      if (!referral) {
        const portal = await mintPartnerInvite({ igUserId: normalized.igUserId, igUsername: normalized.igUsername });
        const persistedReferral = await insertReferral({
          campaignId: ENV.campaignId,
          mediaId: normalized.postId,
          partnerIgUserId: normalized.igUserId,
          partnerUsername: normalized.igUsername,
          partnerCode: portal.code,
          inviteUrl: portal.invite_url,
          partnerCommentId: normalized.commentId,
          language: "fa",
          portalIsNew: portal.is_new ? 1 : 0,
        });
        if (!persistedReferral) throw new Error("REFERRAL_NOT_PERSISTED");
        referral = persistedReferral;
      }

      const messageResult = await sendPrivateReply({
        postId: normalized.postId,
        commentId: normalized.commentId,
        message: buildPartnerMessage(referral.partnerCode),
      }) as { messageId?: string; id?: string };
      await insertMessageEvent({
        recipientIgUserId: normalized.igUserId,
        commentId: normalized.commentId,
        messageType: "partner_code",
        providerMessageId: messageResult?.messageId ?? messageResult?.id,
        status: "sent",
      });
      await markWebhookEvent(normalized.eventId, "processed");
      return { status: 200, body: { ok: true, type: "partner_code_sent", code: referral.partnerCode } };
    }

    const partnerCode = extractFriendCode(normalized.text);
    if (!partnerCode) {
      await markWebhookEvent(normalized.eventId, "ignored");
      return { status: 200, body: { ok: true, ignored: "keyword_or_partner_code_not_matched" } };
    }

    const referral = await getReferralByCode(partnerCode, normalized.postId, ENV.campaignId);
    if (!referral) {
      await markWebhookEvent(normalized.eventId, "ignored", "partner_code_not_found");
      return { status: 200, body: { ok: true, ignored: "partner_code_not_found" } };
    }
    if (await hasMessageForComment(normalized.commentId, "friend_invite_link")) {
      await markWebhookEvent(normalized.eventId, "processed");
      return { status: 200, body: { ok: true, duplicate: true, reason: "friend_link_already_sent" } };
    }

    await insertFriendCodeEvent({
      commentId: normalized.commentId,
      mediaId: normalized.postId,
      partnerCode,
      friendIgUserId: normalized.igUserId,
      friendUsername: normalized.igUsername,
      verificationMethod: "share_confirmed_by_friend_code",
      status: "received",
    });
    const messageResult = await sendPrivateReply({
      postId: normalized.postId,
      commentId: normalized.commentId,
      message: buildFriendMessage(referral.inviteUrl),
    }) as { messageId?: string; id?: string };
    await insertMessageEvent({
      recipientIgUserId: normalized.igUserId,
      commentId: normalized.commentId,
      messageType: "friend_invite_link",
      providerMessageId: messageResult?.messageId ?? messageResult?.id,
      status: "sent",
    });
    await markWebhookEvent(normalized.eventId, "processed");
    return { status: 200, body: { ok: true, type: "friend_invite_link_sent" } };
  } catch (error) {
    const code = error instanceof Error ? error.message.split(":", 1)[0] : "PROCESSING_ERROR";
    await markWebhookEvent(normalized.eventId, "failed", code);
    if (code === "PORTAL_TOKEN_INVALID") return { status: 401, body: { ok: false, error: "portal_token_must_be_fixed_in_configuration" } };
    return { status: 500, body: { ok: false, error: code } };
  }
}

export function registerZernioWebhookRoutes(app: Express) {
  app.get("/api/health", (_req, res) => {
    res.json({ ok: true, service: "bazino-affiliate-webhook", campaign: ENV.campaignId, mediaId: ENV.testMediaId });
  });

  app.post("/api/webhooks/zernio", async (req, res) => {
    const signature = req.header("X-Zernio-Signature");
    if (!verifyZernioSignature(getRawBody(req), signature)) {
      return sendJson(res, 401, { ok: false, error: "invalid_signature" });
    }
    const result = await handleCommentEvent(req);
    return sendJson(res, result.status, result.body);
  });
}

export { handleCommentEvent };
