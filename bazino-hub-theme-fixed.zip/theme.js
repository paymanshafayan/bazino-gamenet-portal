/* Bazino Gaming Club Hub v2.0.0 — theme.js — بازطراحی کامل بر اساس موکاپ‌های کاربر
   منوها/مسیرها مستند به src/utils/routes.ts پورتال: HUB_PAGES = home, games, events,
   weekly, special, season, brackets, register, shop, food, club, blog, chat, contact, rules, privacy */
!function () {
  var SDK = typeof window !== "undefined" ? window.BazinoThemeSDK : null;
  var t = (SDK && SDK.React) ? SDK.React : (typeof window !== "undefined" ? window.React : null);
  if (!SDK || !SDK.registerComponent || !t) return;
  var h = t.createElement;
  var useState = t.useState;

  function wrap(Comp) {
    var fn = function (props) {
      if (arguments.length === 0) return { apiVersion: 2, render: function (p) { return h(Comp, p || {}); } };
      return h(Comp, props || {});
    };
    fn.apiVersion = 2;
    fn.render = function (p) { return h(Comp, p || {}); };
    return fn;
  }

  function Icon(paths) {
    return h("svg", { viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: 1.8, strokeLinecap: "round", strokeLinejoin: "round" },
      paths.map(function (d, i) { return h("path", { key: i, d: d }); }));
  }
  var I = {
    games: ["M6 10h4M8 8v4", "M15 11h.01M17 9h.01", "M7 6h10a4 4 0 0 1 4 4v4a4 4 0 0 1-4 4h-1l-2-2h-4l-2 2H7a4 4 0 0 1-4-4v-4a4 4 0 0 1 4-4z"],
    trophy: ["M8 4h8v4a4 4 0 0 1-8 0V4z", "M6 4H4v2a4 4 0 0 0 4 4M18 4h2v2a4 4 0 0 1-4 4", "M12 12v4M9 20h6"],
    shop: ["M6 8h12l-1 12H7L6 8z", "M9 8V6a3 3 0 0 1 6 0v2"],
    food: ["M4 9h13v6a4 4 0 0 1-4 4H8a4 4 0 0 1-4-4V9z", "M17 10h1a3 3 0 0 1 0 6h-1"],
    club: ["M12 3l7 3v6c0 4.5-3 7.5-7 9-4-1.5-7-4.5-7-9V6z"],
    blog: ["M5 4h14v13H9l-4 4V4z"],
    chat: ["M4 5h16v11H8l-4 4V5z"],
    kids: ["M12 4a3 3 0 1 1 0 6 3 3 0 0 1 0-6z", "M6 20c0-3.3 2.7-6 6-6s6 2.7 6 6"],
    adults: ["M12 2l3 5h5l-4 4 1.5 6L12 14l-5.5 3L8 11 4 7h5z"],
    request: ["M12 8v5M12 16h.01", "M12 3l9 6v6l-9 6-9-6V9z"],
    weekly: ["M4 5h16v15H4z", "M4 9h16", "M8 3v4M16 3v4"],
    special: ["M12 3l2.5 6H21l-5 4 2 7-6-4-6 4 2-7-5-4h6.5z"],
    season: ["M4 19h4v-5H4zM10 19h4v-9h-4zM16 19h4v-3h-4z"],
    bracket: ["M4 4v6h5M4 20v-6h5M9 7h4l4 5-4 5H9", "M9 7V4M9 20v-3"],
    heart: ["M12 20s-7-4.5-9.5-8.5C.6 8 2 4 6 4c2 0 3.5 1.2 6 4 2.5-2.8 4-4 6-4 4 0 5.4 4 3.5 7.5C19 15.5 12 20 12 20z"],
    pin: ["M12 21s7-6.5 7-11a7 7 0 1 0-14 0c0 4.5 7 11 7 11z", "M12 12a2 2 0 1 0 0-4 2 2 0 0 0 0 4z"],
    clock: ["M12 22a10 10 0 1 0 0-20 10 10 0 0 0 0 20z", "M12 7v5l4 2"],
    whatsapp: ["M4 20l1.4-4.2A8 8 0 1 1 8.7 19L4 20z"],
    insta: ["M4 4h16v16H4z", "M12 8.5a3.5 3.5 0 1 0 0 7 3.5 3.5 0 0 0 0-7z", "M17 6.5h.01"],
    star: ["M12 3l2.5 6H21l-5 4 2 7-6-4-6 4 2-7-5-4h6.5z"],
    shield: ["M12 3l7 3v6c0 4.5-3 7.5-7 9-4-1.5-7-4.5-7-9V6z"],
    gift: ["M4 8h16v4H4zM6 8v11h12V8M12 8V6a2 2 0 1 1 2 2M12 8V6a2 2 0 1 0-2 2"],
    ok: ["M20 6L9 17l-5-5"]
  };
  function ic(name) { return Icon(I[name] || I.star); }

  var ROUTES = { home: "/", games: "/games", events: "/events", weekly: "/events/weekly", special: "/events/special", season: "/events/season", brackets: "/events/brackets", register: "/events/register", shop: "/shop", food: "/food", club: "/club", blog: "/blog", chat: "/chat", contact: "/contact", rules: "/rules", privacy: "/privacy" };
  function go(p, path) { if (p && p.onNavigate) p.onNavigate(path); else if (typeof window !== "undefined") window.location.href = path; }

  /* ───────── HEADER ───────── */
  function Header(p) {
    var items = [["home", "خانه"], ["games", "بازی‌ها"], ["events", "مسابقات"], ["shop", "فروشگاه"], ["food", "کافه"], ["club", "باشگاه"], ["blog", "بلاگ"], ["chat", "چت"]];
    return h("header", { className: "bzh bzh-header" },
      h("a", { href: ROUTES.home, className: "bzh-logo" }, h("b", null, "BAZINO"), h("span", null, "GAMING CLUB")),
      h("nav", { className: "bzh-nav" }, items.map(function (it) {
        return h("a", { key: it[0], href: ROUTES[it[0]], className: (p.currentRoute || "home") === it[0] ? "is-on" : "" }, it[1]);
      })),
      h("div", { className: "bzh-actions" },
        h("div", { className: "bzh-lang" }, "FA ▾"),
        h("a", { className: "bzh-btn", href: ROUTES.register }, "ثبت‌نام"),
        h("button", { className: "bzh-btn solid" }, "ورود")
      )
    );
  }

  /* ───────── FOOTER ───────── */
  function Footer() {
    return h("div", { className: "bzh bzh-footerbar" },
      h("div", null, ic("pin"), h("span", null, h("b", null, "ایسکله، لانگ بیچ "), "— هتل ویستامار")),
      h("div", null, ic("clock"), h("span", null, "هر روز ", h("b", null, "۱۱:۰۰ – ۲۳:۵۰"))),
      h("div", null, ic("whatsapp"), h("b", null, "۳۷ ۱۲ ۱۱۲ ۵۳۹ 90+")),
      h("div", null, ic("insta"), h("b", null, "bazinopro@"))
    );
  }
  function Page(children) { return h("div", { className: "bzh" }, children, h(Footer)); }

  /* ───────── HOME ───────── */
  function Home(p) {
    var tiles = [["games", "GAMES", "بازی برای کودکان و بزرگسالان"], ["events", "EVENTS", "تورنومنت و رویدادهای ویژه"], ["shop", "SHOP", "تجهیزات و اکسسوری گیمینگ"], ["food", "FOOD & DRINKS", "تنقلات و نوشیدنی"], ["club", "CLUB", "درباره‌ی باشگاه بازینو"], ["blog", "BLOG", "اخبار و مطالب بازینو"], ["chat", "CHAT", "چت و پشتیبانی"]];
    return Page(
      h("section", { className: "bzh-hero" },
        h("div", { className: "bzh-hero-badge" }, "اکنون"),
        h("h2", null, "بازینو گیمینگ کلاب"),
        h("p", null, "بهترین تجربه‌ی بازی روی کنسول‌های نسل جدید — رزرو، تورنومنت و جامعه‌ی بازیکنان."),
        h("a", { className: "bzh-hero-cta", href: ROUTES.games }, "شروع کن به بازی")
      ),
      h("div", { className: "bzh-tiles" }, tiles.map(function (tl) {
        return h("a", { key: tl[0], className: "bzh-tile", href: ROUTES[tl[0]] },
          h("div", { className: "bzh-tile-icon" }, ic(tl[0])),
          h("b", null, tl[1]), h("span", null, tl[2])
        );
      }))
    );
  }

  /* ───────── GAMES (category switch) ───────── */
  var KIDS_GAMES = [["Astro's Playroom", ["پلتفرمر", "ماجراجویی"], "3", "green", "1-2 نفره"], ["Minecraft", ["ماجراجویی", "خلاقانه"], "7", "green", "1-4 نفره"], ["LEGO Fortnite", ["اکشن", "ماجراجویی"], "7", "green", "1-4 نفره"], ["Rocket League", ["ورزشی", "ریسینگ"], "3", "green", "1-4 نفره"], ["Fall Guys", ["مهمانی", "اکشن"], "3", "green", "1-4 نفره"]];
  var ADULT_GAMES = [["EA SPORTS FC 26", ["ورزشی", "فوتبال"], "3", "green", "1-4 نفره"], ["NBA 2K25", ["ورزشی", "بسکتبال"], "3", "green", "1-4 نفره"], ["Call of Duty: MWIII", ["اکشن", "شوتر"], "18", "magenta", "1-4 نفره"], ["Grand Theft Auto V", ["اکشن", "دنیای باز"], "18", "magenta", "1-4 نفره"], ["Tekken 8", ["فایتینگ"], "16", "orange", "1-2 نفره"], ["UFC 5", ["ورزشی", "فایتینگ"], "16", "orange", "1-2 نفره"]];
  function GameRow(g) {
    var pegiColor = g[3] === "green" ? "var(--green)" : g[3] === "magenta" ? "var(--magenta)" : "var(--orange)";
    return h("div", { className: "bzh-row", key: g[0] },
      h("div", { className: "bzh-row-badge", style: { background: "linear-gradient(135deg,var(--cyan),var(--violet))" } }, g[0].split(" ").slice(0, 2).join(" ")),
      h("div", { className: "bzh-row-body" },
        h("b", null, g[0]),
        h("div", { className: "bzh-row-tags" }, g[1].map(function (tg) { return h("span", { className: "bzh-tag", key: tg }, tg); })),
        h("div", { className: "bzh-row-desc" }, g[4], " · PS5 · آنلاین/آفلاین")
      ),
      h("div", { className: "bzh-row-meta" }, h("span", { className: "bzh-pegi", style: { background: pegiColor } }, g[2]), "PEGI")
    );
  }
  function GamesPage(p) {
    var s = useState("hub"); var view = s[0], setView = s[1];
    if (view === "hub") {
      return Page(
        h("div", { className: "bzh-pagehero" }, h("h1", null, "بازی‌ ", h("em", null, "ها")), h("p", null, "دسته‌ی موردنظرت رو انتخاب کن")),
        h("div", { className: "bzh-cat-grid" },
          h("div", { className: "bzh-cat-card", onClick: function () { setView("kids"); } }, h("div", { className: "bzh-cat-icon" }, ic("kids")), h("b", null, "کودکان"), h("span", null, "بازی‌های امن و مناسب سن پایین")),
          h("div", { className: "bzh-cat-card", onClick: function () { setView("adults"); } }, h("div", { className: "bzh-cat-icon" }, ic("adults")), h("b", null, "بزرگسالان"), h("span", null, "اکشن، ورزشی، ریسینگ و بیشتر")),
          h("div", { className: "bzh-cat-card", onClick: function () { setView("request"); } }, h("div", { className: "bzh-cat-icon" }, ic("request")), h("b", null, "درخواست بازی"), h("span", null, "پیشنهاد بازی جدید به باشگاه"))
        )
      );
    }
    if (view === "request") {
      return Page(
        h("div", { className: "bzh-pagehero" }, h("span", { className: "bzh-back", onClick: function () { setView("hub"); } }, "← بازگشت"), h("h1", null, "درخواست ", h("em", null, "بازی"))),
        h("div", { className: "bzh-register" },
          h("div", { className: "bzh-field" }, h("label", null, "نام بازی پیشنهادی"), h("input", { placeholder: "مثلاً Elden Ring" })),
          h("div", { className: "bzh-field" }, h("label", null, "توضیح کوتاه (اختیاری)"), h("input", { placeholder: "چرا این بازی رو می‌خوای؟" })),
          h("button", { className: "bzh-submit" }, "ارسال درخواست")
        )
      );
    }
    var list = view === "kids" ? KIDS_GAMES : ADULT_GAMES;
    return Page(
      h("div", { className: "bzh-pagehero" }, h("span", { className: "bzh-back", onClick: function () { setView("hub"); } }, "← بازگشت به بازی‌ها"), h("h1", null, view === "kids" ? "بازی‌های " : "بازی‌های ", h("em", null, view === "kids" ? "کودکان" : "بزرگسالان"))),
      h("div", { className: "bzh-list" }, list.map(GameRow))
    );
  }

  /* ───────── EVENTS HUB ───────── */
  function EventsHub(p) {
    var cards = [
      ["weekly", "تورنومنت‌های هفتگی", "رقابت منظم هفتگی", ["۳۲ بازیکن", "فرمت حذفی", "هر شنبه"]],
      ["special", "رویدادهای ویژه", "مسابقات بزرگ و جوایز نقدی", ["جوایز بزرگ‌تر", "بازی‌های متنوع", "کاپ‌های اختصاصی"]],
      ["season", "رتبه‌بندی فصل", "رتبه‌بندی زنده‌ی فصل", ["امتیاز زنده", "مقایسه با دیگران", "قهرمان فصل"]],
      ["brackets", "براکت مسابقات", "نتایج زنده و گذشته", ["مسابقه‌ی جاری", "براکت کامل", "نتایج و برندگان"]]
    ];
    return Page(
      h("div", { className: "bzh-pagehero" }, h("h1", null, "مسابقات ", h("em", null, "بازینو"))),
      h("div", { className: "bzh-ev-grid" }, cards.map(function (c) {
        return h("div", { className: "bzh-ev-card", key: c[0] },
          h("div", { className: "bzh-ev-icon" }, ic(c[0])),
          h("b", null, c[1]), h("div", { style: { fontSize: "11px", color: "var(--muted)" } }, c[2]),
          h("ul", null, c[3].map(function (x) { return h("li", { key: x }, x); })),
          h("a", { className: "bzh-ev-more", href: ROUTES[c[0]] }, "مشاهده →")
        );
      }))
    );
  }

  /* ───────── WEEKLY ───────── */
  var WEEKLY = [["FC 26", "هر شنبه", "۳۲ نفر", "۵۰۰ BC"], ["UFC 5", "هر سه‌شنبه", "۱۶ نفر", "۳۰۰ BC"], ["Mortal Kombat 1", "هر پنج‌شنبه", "۱۶ نفر", "۳۰۰ BC"], ["Tekken 8", "هر جمعه", "۱۶ نفر", "۳۰۰ BC"]];
  function WeeklyPage() {
    return Page(
      h("div", { className: "bzh-pagehero" }, h("span", { className: "bzh-back" }, "← بازگشت به مسابقات"), h("h1", null, "تورنومنت‌های ", h("em", null, "هفتگی"))),
      h("div", { className: "bzh-list" }, WEEKLY.map(function (w) {
        return h("div", { className: "bzh-tourn", key: w[0] },
          h("div", { className: "bzh-tourn-logo" }, w[0].split(" ")[0]),
          h("div", { className: "bzh-tourn-body" }, h("b", null, w[0] + " — تورنومنت هفتگی"), h("div", { className: "bzh-tourn-meta" }, h("span", null, w[1]), h("span", null, w[2]), h("span", null, "جایزه: " + w[3]))),
          h("a", { className: "bzh-tourn-cta", href: ROUTES.brackets }, "جزئیات")
        );
      }))
    );
  }

  /* ───────── SPECIAL ───────── */
  var SPECIAL = [["FC 26 Champions Cup", "۱۵۰ ت", "۲۰۰۰ ت", "۶۴ نفر"], ["UFC 5 Fight Night", "۲۰۰ ت", "۱۵۰۰ ت", "۳۲ نفر"], ["Mortal Kombat Legends", "۱۵۰ ت", "۱۲۰۰ ت", "۳۲ نفر"], ["Tekken 8 Championship", "۲۰۰ ت", "۱۰۰۰ ت", "۳۲ نفر"]];
  function SpecialPage() {
    return Page(
      h("div", { className: "bzh-pagehero" }, h("span", { className: "bzh-back" }, "← بازگشت به مسابقات"), h("h1", null, "رویدادهای ", h("em", null, "ویژه"))),
      h("div", { className: "bzh-list" }, SPECIAL.map(function (w) {
        return h("div", { className: "bzh-tourn", key: w[0] },
          h("div", { className: "bzh-tourn-logo" }, w[0].split(" ")[0]),
          h("div", { className: "bzh-tourn-body" }, h("b", null, w[0]), h("div", { className: "bzh-tourn-meta" }, h("span", null, "ورودی " + w[1]), h("span", null, "جایزه اول " + w[2]), h("span", null, w[3]))),
          h("a", { className: "bzh-tourn-cta", href: ROUTES.register }, "ثبت‌نام")
        );
      }))
    );
  }

  /* ───────── SEASON ───────── */
  var LB = [["ArmanK", "۴۸"], ["RezaB", "۴۲"], ["Mahan10", "۳۵"], ["Shayan", "۲۸"], ["AliGameR", "۲۵"], ["DarkLord", "۲۳"], ["NimaPro", "۲۰"], ["RezaMVP", "۱۸"]];
  function SeasonPage() {
    return Page(
      h("div", { className: "bzh-pagehero" }, h("span", { className: "bzh-back" }, "← بازگشت به مسابقات"), h("h1", null, "رتبه‌بندی ", h("em", null, "فصل"))),
      h("div", { className: "bzh-season" },
        h("div", { className: "bzh-side-panel" }, h("b", null, "سیستم امتیاز"), h("p", { style: { fontSize: "11px", color: "var(--muted)", marginTop: 10 } }, "مقام اول: ۵ امتیاز — مقام دوم: ۲ — مقام سوم: ۱")),
        h("table", { className: "bzh-lb-table" },
          h("thead", null, h("tr", null, h("th", null, "#"), h("th", null, "بازیکن"), h("th", null, "امتیاز"))),
          h("tbody", null, LB.map(function (row, i) {
            return h("tr", { key: row[0] }, h("td", null, i + 1), h("td", null, row[0]), h("td", null, row[1]));
          }))
        ),
        h("div", { className: "bzh-side-panel" }, h("b", null, "برترین‌های فصل"), h("p", { style: { fontSize: "11px", color: "var(--muted)", marginTop: 10 } }, "۱. ArmanK — ۴۸ امتیاز", h("br"), "۲. RezaB — ۴۲ امتیاز", h("br"), "۳. Mahan10 — ۳۵ امتیاز"))
      )
    );
  }

  /* ───────── BRACKETS (ساده‌شده) ───────── */
  function BracketsPage() {
    var r16 = [["ArmanK", "RezaFun", 1], ["AliGameR", "Parham", 1], ["Shayan", "AmirT", 1], ["NimaPro", "DarkLord", 1]];
    var sf = [["ArmanK", "AliGameR", 1], ["Shayan", "NimaPro", 1]];
    var final = ["ArmanK", "Shayan", 1];
    function match(pair) {
      return h("div", { className: "bzh-match" },
        h("div", { className: "bzh-match-p" + (pair[2] === 1 ? " win" : "") }, pair[0]),
        h("div", { className: "bzh-match-p" }, pair[1])
      );
    }
    return Page(
      h("div", { className: "bzh-pagehero" }, h("span", { className: "bzh-back" }, "← بازگشت به مسابقات"), h("h1", null, "براکت ", h("em", null, "FC26 — هفته #۱۳"))),
      h("div", { className: "bzh-bracket-wrap" },
        h("div", { className: "bzh-bracket" },
          h("div", { className: "bzh-bracket-round" }, h("div", { className: "bzh-bracket-round-title" }, "یک‌هشتم نهایی"), r16.map(match)),
          h("div", { className: "bzh-bracket-round" }, h("div", { className: "bzh-bracket-round-title" }, "نیمه‌نهایی"), sf.map(match)),
          h("div", { className: "bzh-champion" }, h("div", { className: "bzh-champion-badge" }, ic("trophy")), h("b", null, final[0]), h("div", { style: { fontSize: "10px", color: "var(--muted)" } }, "قهرمان"))
        )
      )
    );
  }

  /* ───────── REGISTER ───────── */
  function RegisterPage() {
    return Page(
      h("div", { className: "bzh-pagehero" }, h("h1", null, "ساخت ", h("em", null, "حساب کاربری"))),
      h("div", { className: "bzh-register" },
        h("div", { className: "bzh-field-row" }, h("div", { className: "bzh-field" }, h("label", null, "نام"), h("input", null)), h("div", { className: "bzh-field" }, h("label", null, "نام خانوادگی"), h("input", null))),
        h("div", { className: "bzh-field" }, h("label", null, "نام کاربری"), h("input", { placeholder: "۶ تا ۱۲ کاراکتر" })),
        h("div", { className: "bzh-field" }, h("label", null, "تاریخ تولد"), h("input", { type: "date" })),
        h("div", { className: "bzh-field" }, h("label", null, "شماره تلفن"), h("input", { placeholder: "+90 ..." })),
        h("div", { className: "bzh-field" }, h("label", null, "رمز عبور"), h("input", { type: "password" })),
        h("button", { className: "bzh-submit" }, "ساخت حساب کاربری")
      )
    );
  }

  /* ───────── SHOP / FOOD (coming soon) ───────── */
  function ComingSoon(title, icons, feats) {
    return Page(
      h("div", { className: "bzh-soon" },
        h("div", { className: "bzh-soon-icons" }, icons.map(function (n, i) { return h("span", { key: i }, ic(n)); })),
        h("h1", null, title, h("br"), h("em", null, "به‌زودی!")),
        h("p", null, "این بخش داره برای شما آماده می‌شه."),
        h("div", { className: "bzh-soon-feats" }, feats.map(function (f) {
          return h("div", { className: "bzh-soon-feat", key: f[1] }, ic(f[0]), h("b", null, f[1]), h("span", null, f[2]));
        }))
      )
    );
  }
  function ShopPage() { return ComingSoon("فروشگاه", ["shop", "gift", "star"], [["gift", "اقلام اختصاصی", "فقط برای اعضای بازینو"], ["star", "تخفیف‌های ویژه", "پیشنهادهای محدود"], ["shield", "کیفیت بالا", "انتخاب‌شده برای گیمرها"], ["heart", "مزایای عضویت", "پاداش‌های اختصاصی اعضا"]]); }
  function FoodPage() { return ComingSoon("کافه و رستوران", ["food", "heart", "star"], [["food", "غذای خوشمزه", "برای هر بازیکن"], ["star", "نوشیدنی خنک", "بمون و بیشتر بازی کن"], ["gift", "تنوع بیشتر", "تنقلات و دسر"], ["heart", "همون فضای دوست‌داشتنی", "غذای خوب، بازی خوب"]]); }

  /* ───────── CLUB / ABOUT ───────── */
  function ClubPage() {
    return Page(
      h("div", { className: "bzh-about" },
        h("h1", null, "BAZINO"), h("h2", null, "GAMING CLUB"),
        h("p", null, "بازینو یه باشگاه گیمینگه در ایسکله، لانگ بیچ، برای آدم‌هایی که بازی، رقابت و گذروندن وقت خوب با هم رو دوست دارن. چه بازیکن آماتور باشی چه رقیب جدی، بازینو جاییه که بازی می‌کنی، آدم می‌بینی و بهش تعلق داری."),
        h("div", { className: "bzh-about-feats" },
          h("div", null, ic("games"), h("b", null, "گیمینگ PS5"), h("span", null, "جدیدترین بازی‌ها روی کنسول نسل جدید")),
          h("div", null, ic("star"), h("b", null, "تجربه‌ی صفحه‌ی بزرگ"), h("span", null, "صفحه‌های بزرگ‌تر، لحظات بزرگ‌تر")),
          h("div", null, ic("trophy"), h("b", null, "تورنومنت و رویداد"), h("span", null, "شرکت در مسابقات و برنده‌شدن جوایز")),
          h("div", null, ic("club"), h("b", null, "فضای دوستانه"), h("span", null, "بازی کن، آروم باش، عضو جامعه شو"))
        ),
        h("div", { className: "bzh-visit" },
          h("div", { style: { display: "flex", alignItems: "center", gap: 10 } }, ic("pin"), h("span", null, h("b", null, "ایسکله، لانگ بیچ"), h("br"), "هتل ویستامار")),
          h("a", { className: "bzh-btn solid", href: "https://maps.google.com", target: "_blank", rel: "noreferrer" }, "مسیریابی")
        )
      )
    );
  }

  /* ───────── SIMPLE TEXT PAGES ───────── */
  function TextPage(title, body) {
    return Page(h("div", { className: "bzh-pagehero" }, h("h1", null, title)), h("div", { className: "bzh-text" }, body));
  }
  function ContactPage() { return TextPage("تماس با ما", h("p", null, "ایسکله، لانگ بیچ، هتل ویستامار — واتس‌اپ: 47 37 112 539 90+ — اینستاگرام: bazinopro@")); }
  function RulesPage() { return TextPage("قوانین باشگاه", h("p", null, "با ورود به بازینو، پذیرفتن قوانین باشگاه الزامی است. جزئیات کامل به‌زودی تکمیل می‌شود.")); }
  function PrivacyPage() { return TextPage("حریم خصوصی", h("p", null, "بازینو به حریم خصوصی اعضا احترام می‌گذارد. جزئیات کامل سیاست حریم خصوصی به‌زودی تکمیل می‌شود.")); }
  function BlogPage() { return ComingSoon("بلاگ", ["blog", "star", "heart"], [["blog", "اخبار باشگاه", "تازه‌ترین خبرها"], ["trophy", "گزارش مسابقات", "خلاصه‌ی تورنومنت‌ها"], ["star", "معرفی بازی", "بازی‌های جدید"], ["heart", "داستان اعضا", "از زبان بازیکنان"]]); }
  function ChatPage() { return ComingSoon("چت باشگاه", ["chat", "heart", "star"], [["chat", "چت زنده", "ارتباط با سایر اعضا"], ["heart", "پشتیبانی", "پاسخ سریع تیم بازینو"], ["star", "اعلان‌ها", "خبر مسابقات و رویدادها"], ["club", "جامعه‌ی بازینو", "با هم در ارتباط باشید"]]); }

  SDK.registerComponent("header", wrap(Header));
  SDK.registerComponent("hero", wrap(Home));
  SDK.registerComponent("home", wrap(Home));
  SDK.registerComponent("hub.home", wrap(Home));
  SDK.registerComponent("hub.games", { apiVersion: 2, render: function (p) { return h(GamesPage, p || {}); } });
  SDK.registerComponent("hub.events", wrap(EventsHub));
  SDK.registerComponent("hub.weekly", wrap(WeeklyPage));
  SDK.registerComponent("hub.special", wrap(SpecialPage));
  SDK.registerComponent("hub.season", wrap(SeasonPage));
  SDK.registerComponent("hub.brackets", wrap(BracketsPage));
  SDK.registerComponent("hub.register", wrap(RegisterPage));
  SDK.registerComponent("hub.shop", wrap(ShopPage));
  SDK.registerComponent("hub.food", wrap(FoodPage));
  SDK.registerComponent("hub.club", wrap(ClubPage));
  SDK.registerComponent("hub.blog", wrap(BlogPage));
  SDK.registerComponent("hub.chat", wrap(ChatPage));
  SDK.registerComponent("hub.contact", wrap(ContactPage));
  SDK.registerComponent("hub.rules", wrap(RulesPage));
  SDK.registerComponent("hub.privacy", wrap(PrivacyPage));

  if (typeof console !== "undefined") console.log("Bazino Hub v2.0.0 — بازطراحی کامل بارگذاری شد.");
}();
