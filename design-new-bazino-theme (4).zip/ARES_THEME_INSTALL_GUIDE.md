# 🎮 ARES HUD Theme - Installation Guide for Bazino

## 📁 Theme Files Structure

```
src/
├── components/
│   └── AresHudHome.tsx       # Main theme component (1066 lines)
├── index.css                  # Ares CSS styles (to be merged)
```

---

## 🔧 Installation Steps for Bazino Project

### Step 1: Copy Component File

Copy `src/components/AresHudHome.tsx` to your Bazino project:

```bash
cp src/components/AresHudHome.tsx /path/to/bazino/src/components/
```

### Step 2: Merge CSS Styles

Add the Ares CSS styles to your `src/index.css`. 

The key CSS classes to add:
- `.neon-frame` / `.hud-panel` - Glass morphism panels
- `.ares-btn` / `.ares-btn-primary` / `.ares-btn-gold` - Neon buttons
- `.ares-card` - Hover cards with gradient rim
- `.ares-badge` / `.ares-badge-cyan` / `.ares-badge-gold` - Status badges
- `.ares-input` - Neon focus inputs
- `.ares-progress` / `.ares-progress-bar` - Gradient progress bars
- `.text-glow` / `.text-glow-cyan` / `.text-glow-gold` - Text glow effects
- `.ares-icon-btn` - Icon buttons
- `.ares-divider` - Gradient dividers
- `.ares-grid-bg` - Background grid pattern

### Step 3: Add CSS Variables (body[data-theme='ares-hud'])

Add theme-specific variables to your CSS:

```css
body[data-theme='ares-hud'] {
  --background: oklch(0.12 0.03 275);
  --foreground: oklch(0.96 0.01 280);
  --primary: oklch(0.62 0.24 300);
  --neon-purple: oklch(0.62 0.26 300);
  --neon-cyan: oklch(0.78 0.15 200);
  --neon-gold: oklch(0.82 0.16 85);
  /* ... other variables */
}
```

### Step 4: Register Theme in App.tsx

Add to `availableThemes` array:

```tsx
const availableThemes = [
  // ... existing themes
  {
    id: 'ares-hud',
    name: {
      fa: 'آرس HUD',
      en: 'Ares HUD',
      ru: 'Арес ХУД',
      tr: 'Ares HUD'
    },
    description: {
      fa: 'قالب سایبرپانک با افکت‌های شیشه‌ای و نئونی',
      en: 'Cyberpunk theme with glass morphism and neon effects',
      ru: 'Киберпанк тема со стеклянными эффектами',
      tr: 'Cam efektleri ve neon detaylarıyla siber punk tema'
    },
    preview: '/themes/ares-hud-preview.png',
    primaryColor: '#9333ea',
    accentColor: '#22d3ee'
  }
];
```

### Step 5: Add Conditional Render in HomeTab.tsx

Add before the default return:

```tsx
if (themeId === 'ares-hud') {
  return (
    <AresHudHome
      featuredGames={activeBanners}
      matchHistory={matchHistory}
      pricingPackages={pricingPackages}
      loungeSections={loungeSections}
      tournaments={tournaments}
      staffTeam={staffTeam}
      onNavigate={onNavigate}
      language={language}
    />
  );
}
```

### Step 6: Add Font Import

Ensure Google Fonts are loaded in `index.html`:

```html
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;500;600;700;800;900&family=Rajdhani:wght@300;400;500;600;700&display=swap" rel="stylesheet">
```

---

## 🎨 Theme Color Palette

| Color | OKLCH Value | Usage |
|-------|-------------|-------|
| Background | `oklch(0.12 0.03 275)` | Main dark background |
| Neon Purple | `oklch(0.62 0.26 300)` | Primary accent, buttons, glow |
| Neon Cyan | `oklch(0.78 0.15 200)` | Secondary accent, icons |
| Neon Gold | `oklch(0.82 0.16 85)` | Highlights, badges, stars |

---

## 📐 Theme Sections (8 Bazino Standard Sections)

1. **Hero Section** - Full-width slider with countdown timer
2. **Service Shortcuts** - Circular lounge section buttons
3. **Gaming Stations** - Hardware cards with stats
4. **About Story** - Club info with statistics grid
5. **Match Center** - Live scoreboard with match list
6. **Tournaments Hub** - Active tournaments with progress bars
7. **Pricing Packages** - 3-column pricing cards
8. **Coaches/Staff** - Team member cards with avatars

---

## 🔌 Props Interface

```typescript
interface AresHudHomeProps {
  featuredGames?: FeaturedGame[];
  matchHistory?: MatchRecord[];
  pricingPackages?: PricingPackage[];
  loungeSections?: LoungeSection[];
  tournaments?: Tournament[];
  staffTeam?: StaffMember[];
  onNavigate?: (tab: string) => void;
  language?: 'fa' | 'en' | 'ru' | 'tr';
}
```

---

## ✨ Key Visual Features

- **Glass Morphism Panels** - `.neon-frame` / `.hud-panel` with blur(18px)
- **Gradient Rim Borders** - Beveled edges with cyan-to-purple gradient
- **Text Glow Effects** - Neon purple text shadows
- **Animated Elements** - Pulse, float, and scan-line animations
- **Dark Sci-Fi Aesthetic** - Deep purple background with cyan accents
- **Orbitron Font** - Futuristic display typography
- **RTL Support** - Full Persian/Arabic language support

---

## 📱 Responsive Breakpoints

- Mobile: < 768px
- Tablet: 768px - 1024px
- Desktop: > 1024px

All components are fully responsive with mobile-first design.

---

## 🚀 Ready to Use!

After following these steps, select "Ares HUD" from the theme selector in your Bazino admin panel.

---

**Theme Version:** 1.0.0  
**Compatible with:** Bazino Pro v2.x  
**Author:** Bazino Theme Studio
