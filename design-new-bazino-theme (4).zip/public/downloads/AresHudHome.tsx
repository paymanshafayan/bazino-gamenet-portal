/**
 * ============================================
 * ARES HUD THEME - Bazino Gaming Lounge
 * ============================================
 * 
 * Version: 1.0.0
 * Compatible with: Bazino Pro v2.x
 * 
 * INSTALLATION:
 * 1. Copy this file to: src/components/AresHudHome.tsx
 * 2. Add CSS from ares-hud-theme.css to your index.css
 * 3. Register theme in App.tsx availableThemes
 * 4. Add conditional render in HomeTab.tsx
 * 
 * See INSTALL_GUIDE.md for detailed instructions.
 * ============================================
 */

import React, { useState, useEffect } from 'react';
import { 
  Gamepad2, Trophy, Search, ShoppingBag, 
  Play, Star, Home, Monitor, Coffee, Award,
  Wifi, Users, Shield, Heart, Bell, Menu,
  ChevronRight, Hexagon, Swords,
  Mail, Settings, Volume2, ChevronDown, MapPin, Phone, Clock,
  ArrowRight
} from 'lucide-react';

// ==========================================
// TYPE DEFINITIONS
// ==========================================

interface LocalizedText {
  fa?: string;
  en?: string;
  ru?: string;
  tr?: string;
}

interface FeaturedGame {
  id?: string;
  title: LocalizedText;
  desc?: LocalizedText;
  imageUrl: string;
  badge?: string;
}

interface LoungeSection {
  id: string;
  name: LocalizedText;
  desc?: LocalizedText;
}

interface Tournament {
  id: string;
  title: string;
  game: string;
  status: 'Active' | 'Upcoming' | 'Completed';
  registrationFee: number;
  registeredTeamsCount: number;
  maxTeams: number;
  startDate: string;
  prizePool?: number;
}

interface MatchRecord {
  id: string;
  title: LocalizedText;
  teamA: string;
  teamB: string;
  scoreA: number;
  scoreB: number;
  status: 'Live' | 'Finished' | 'Scheduled';
  time: string;
  game: string;
}

interface PricingPackage {
  id: string;
  title: LocalizedText;
  price: number;
  duration: LocalizedText;
  features: LocalizedText[];
  popular?: boolean;
}

interface StaffMember {
  id: string;
  name: LocalizedText;
  gamerTag: string;
  role: LocalizedText;
  avatar: string;
  specialty: string;
}

interface AresHudHomeProps {
  featuredGames?: FeaturedGame[];
  matchHistory?: MatchRecord[];
  pricingPackages?: PricingPackage[];
  loungeSections?: LoungeSection[];
  tournaments?: Tournament[];
  staffTeam?: StaffMember[];
  onNavigate?: (tab: string) => void;
  language?: 'fa' | 'en' | 'ru' | 'tr';
}

// ==========================================
// ARES LOGO COMPONENT
// ==========================================

const AresMark = ({ className = '' }: { className?: string }) => (
  <svg viewBox="0 0 64 64" fill="none" className={className}>
    <path d="M32 4L4 60h12l6-12h24l6 12h12L32 4Zm0 20 8 16H24l8-16Z" fill="currentColor" />
  </svg>
);

// ==========================================
// DEFAULT DATA (For standalone demo)
// ==========================================

const defaultFeaturedGames: FeaturedGame[] = [
  {
    id: 'cs2',
    title: { fa: 'مسابقات بزرگ کانتر استرایک ۲', en: 'Counter-Strike 2 Global Cup' },
    desc: { fa: 'فریم‌ریت بی‌نهایت و پینگ تک‌رقمی را در سالن مجهز به سیستم‌های RTX 5080 تجربه کنید.', en: 'Experience absolute low latency and infinite frames with NVIDIA RTX 5080 rigs.' },
    imageUrl: 'https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=800&q=80',
    badge: 'FPS GLOBAL CHALLENGE'
  },
  {
    id: 'dota2',
    title: { fa: 'دوتا ۲ - مبارزه نهایی جاودانه‌ها', en: 'Dota 2 - Battle of the Ancients' },
    desc: { fa: 'رقابتی‌ترین ورزش الکترونیک جهان را با مانیتورهای ۳۶۰ هرتز تجربه کنید.', en: 'Play the world\'s premiere MOBA with elite ROG 360Hz monitors.' },
    imageUrl: 'https://images.unsplash.com/photo-1511512578047-dfb367046420?auto=format&fit=crop&w=800&q=80',
    badge: 'MOBA ARENA PRO'
  },
  {
    id: 'fifa26',
    title: { fa: 'فیفا ۲۶ - اتاق‌های VIP کنسول', en: 'FIFA 26 - Ultimate Console Rivals' },
    desc: { fa: 'اتاق‌های VIP مجهز به پلی‌استیشن ۵ و تلویزیون‌های ۸۵ اینچی ال‌جی OLED.', en: 'VIP Booths featuring PlayStation 5 and massive LG OLED 85-inch screens.' },
    imageUrl: 'https://images.unsplash.com/photo-1606144042614-b2417e99c4e3?auto=format&fit=crop&w=800&q=80',
    badge: 'VIP CONSOLE ROOM'
  }
];

const defaultLoungeSections: LoungeSection[] = [
  { id: 'reservations', name: { fa: 'سالن فوق‌حرفه‌ای PC Arena', en: 'High-End PC Arena' }, desc: { fa: 'مجهز به RTX 5080 و مانیتور ۳۶۰ هرتز', en: 'RTX 5080 & 360Hz Monitors' } },
  { id: 'consoles', name: { fa: 'بخش VIP کنسول‌ها', en: 'VIP Console Booths' }, desc: { fa: 'PS5 و Xbox با تلویزیون ۸۵ اینچی', en: 'PS5 & Xbox with 85" OLED' } },
  { id: 'cafe', name: { fa: 'کافه گیمینگ هوشمند', en: 'Smart Gaming Cafe' }, desc: { fa: 'سفارش آنلاین و تحویل سر میز', en: 'Online ordering & desk delivery' } },
  { id: 'shop', name: { fa: 'فروشگاه تجهیزات', en: 'Pro Shop' }, desc: { fa: 'لوازم جانبی و تجهیزات گیمینگ', en: 'Gaming gear & accessories' } },
  { id: 'tournaments', name: { fa: 'سالن مسابقات', en: 'Tournament Arena' }, desc: { fa: 'برگزاری تورنمنت‌های حرفه‌ای', en: 'Professional tournaments' } }
];

const defaultTournaments: Tournament[] = [
  { id: 't1', title: 'CS2 Pro League', game: 'CS2', status: 'Active', registrationFee: 150000, registeredTeamsCount: 12, maxTeams: 16, startDate: '۱۴۰۵/۰۲/۱۵', prizePool: 5000000 },
  { id: 't2', title: 'FIFA Champions Cup', game: 'FIFA 26', status: 'Upcoming', registrationFee: 100000, registeredTeamsCount: 8, maxTeams: 32, startDate: '۱۴۰۵/۰۲/۲۰', prizePool: 3000000 },
  { id: 't3', title: 'Dota 2 Arena', game: 'Dota 2', status: 'Active', registrationFee: 200000, registeredTeamsCount: 6, maxTeams: 8, startDate: '۱۴۰۵/۰۲/۱۸', prizePool: 8000000 }
];

const defaultMatchHistory: MatchRecord[] = [
  { id: 'm1', title: { fa: 'کاپ هفتگی کلن‌های دوتا ۲', en: 'Dota 2 Arena Weekly Cup' }, teamA: 'VIP Gladiators', teamB: 'Persian Hawks', scoreA: 2, scoreB: 1, status: 'Finished', time: '۱۴۰۵/۰۴/۱۴', game: 'Dota 2' },
  { id: 'm2', title: { fa: 'لیگ انتخابی کانتر استرایک ۲', en: 'CS2 Pro League Selection' }, teamA: 'Zero Ping', teamB: 'Cyber Storm', scoreA: 14, scoreB: 10, status: 'Live', time: 'زنده - راند ۲۵', game: 'CS2' },
  { id: 'm3', title: { fa: 'جام قهرمانی باشگاه‌های فیفا ۲۶', en: 'FIFA 26 Club Championship' }, teamA: 'Barca King', teamB: 'Real Madrid Fan', scoreA: 0, scoreB: 0, status: 'Scheduled', time: 'امروز ساعت ۲۱:۰۰', game: 'FIFA 26' }
];

const defaultPricingPackages: PricingPackage[] = [
  {
    id: 'silver', title: { fa: 'پکیج نقره‌ای کلوپ', en: 'Silver Pass Ticket' }, price: 70000,
    duration: { fa: '۳ ساعت بازی با سیستم استاندارد', en: '3 Hours Standard PC Time' },
    features: [
      { fa: 'سیستم‌های گیمینگ RTX 4060', en: 'RTX 4060 Gaming Rig' },
      { fa: 'صندلی‌های ارگونومیک', en: 'Ergonomic Chairs' },
      { fa: '۱ نوشیدنی رایگان', en: '1 Free Drink' }
    ], popular: false
  },
  {
    id: 'gold', title: { fa: 'بلیط طلایی VIP آرنا', en: 'Gold VIP Arena Pass' }, price: 150000,
    duration: { fa: '۵ ساعت بازی با سیستم فوق‌حرفه‌ای', en: '5 Hours VIP PC Time' },
    features: [
      { fa: 'سیستم‌های RTX 5080', en: 'RTX 5080 Extreme Rigs' },
      { fa: 'مانیتور ۳۶۰ هرتز ASUS', en: 'ASUS ROG 360Hz Monitors' },
      { fa: 'ردبول رایگان', en: 'Free RedBull' },
      { fa: '۲ برابر امتیاز وفاداری', en: '2x Loyalty Points' }
    ], popular: true
  },
  {
    id: 'night', title: { fa: 'پکیج شبانه تیمی', en: 'Night-Owl Squad Ticket' }, price: 190000,
    duration: { fa: '۸ ساعت کامل (۱۲ شب الی ۸ صبح)', en: '8 Hours (Midnight to 8 AM)' },
    features: [
      { fa: 'دسترسی به همه سیستم‌ها', en: 'Access Any System' },
      { fa: 'پیتزا + قهوه اسپرسو', en: 'Pizza + Espresso' },
      { fa: 'اینترنت فیبر نوری', en: 'Fiber Internet' }
    ], popular: false
  }
];

const defaultStaffTeam: StaffMember[] = [
  { id: 's1', name: { fa: 'سینا رضایی', en: 'Sina Razavi' }, gamerTag: 'Apex_C', role: { fa: 'سرمربی CS2', en: 'Head CS2 Coach' }, avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Sina', specialty: 'CS2, Valorant' },
  { id: 's2', name: { fa: 'سورنا قاسمی', en: 'Sorena Ghasemi' }, gamerTag: 'Vortex_X', role: { fa: 'تحلیل‌گر MOBA', en: 'Senior MOBA Analyst' }, avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Sorena', specialty: 'Dota 2, LoL' },
  { id: 's3', name: { fa: 'آریا محمدی', en: 'Aria Mohammadi' }, gamerTag: 'Ghost_F', role: { fa: 'مدیر کنسول', en: 'VIP Console Supervisor' }, avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Aria', specialty: 'FIFA, Fighting' }
];

// ==========================================
// MAIN COMPONENT
// ==========================================

export default function AresHudHome({
  featuredGames = defaultFeaturedGames,
  matchHistory = defaultMatchHistory,
  pricingPackages = defaultPricingPackages,
  loungeSections = defaultLoungeSections,
  tournaments = defaultTournaments,
  staffTeam = defaultStaffTeam,
  onNavigate = () => {},
  language = 'en'
}: AresHudHomeProps) {

  const getLocText = (obj: LocalizedText | undefined): string => {
    if (!obj) return '';
    return obj[language] || obj['en'] || '';
  };

  const [currentTime, setCurrentTime] = useState('');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [activeNav, setActiveNav] = useState('home');
  const [activeBanner, setActiveBanner] = useState(0);
  const [timeLeft, setTimeLeft] = useState({ days: 3, hours: 8, mins: 24, secs: 15 });

  useEffect(() => {
    const update = () => setCurrentTime(new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }));
    update();
    const id = setInterval(update, 30000);
    return () => clearInterval(id);
  }, []);

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft(prev => {
        if (prev.secs > 0) return { ...prev, secs: prev.secs - 1 };
        if (prev.mins > 0) return { ...prev, mins: prev.mins - 1, secs: 59 };
        if (prev.hours > 0) return { ...prev, hours: prev.hours - 1, mins: 59, secs: 59 };
        if (prev.days > 0) return { ...prev, days: prev.days - 1, hours: 23, mins: 59, secs: 59 };
        return { days: 4, hours: 12, mins: 0, secs: 0 };
      });
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    if (featuredGames.length === 0) return;
    const interval = setInterval(() => setActiveBanner(prev => (prev + 1) % featuredGames.length), 6000);
    return () => clearInterval(interval);
  }, [featuredGames.length]);

  const padZero = (n: number) => n.toString().padStart(2, '0');
  const isRTL = language === 'fa';

  const navItems = [
    { id: 'home', label: language === 'fa' ? 'خانه' : 'Home', icon: Home },
    { id: 'reservations', label: language === 'fa' ? 'رزرو' : 'Reserve', icon: Monitor },
    { id: 'cafe', label: language === 'fa' ? 'کافه' : 'Cafe', icon: Coffee },
    { id: 'shop', label: language === 'fa' ? 'فروشگاه' : 'Shop', icon: ShoppingBag },
    { id: 'tournaments', label: language === 'fa' ? 'مسابقات' : 'Arena', icon: Trophy },
    { id: 'loyalty', label: language === 'fa' ? 'باشگاه' : 'Club', icon: Award }
  ];

  const t = {
    brandName: 'BAZINO',
    brandSub: language === 'fa' ? 'کلوپ گیمینگ' : 'GAMING LOUNGE',
    heroTitle: language === 'fa' ? 'کلوپ بازی' : 'GAMING',
    heroBrand: language === 'fa' ? 'بازینو' : 'BAZINO',
    heroDesc: language === 'fa' 
      ? 'مدرن‌ترین مرکز گیمینگ و ورزش‌های الکترونیکی. مجهز به سیستم‌های فوق قدرتمند، اتاق‌های VIP مجهز به PS5، بوفه هوشمند آنلاین و مسابقات هفتگی با جوایز نفیس.'
      : 'The most advanced gaming and esports center. Equipped with high-end RTX workstations, custom VIP PS5 booths, smart online café ordering, and pro tournaments.',
    bookNow: language === 'fa' ? 'رزرو سریع سیستم‌ها' : 'BOOK STATION NOW',
    viewAll: language === 'fa' ? 'مشاهده همه' : 'VIEW ALL',
    aboutTitle: language === 'fa' ? 'داستان ما' : 'OUR STORY',
    aboutDesc: language === 'fa'
      ? 'بازینو از سال ۲۰۱۸ با هدف ایجاد بهترین تجربه گیمینگ در ایران تأسیس شد. ما با بهترین تجهیزات و تیم حرفه‌ای آماده خدمت‌رسانی هستیم.'
      : 'BAZINO was founded in 2018 with a mission to create the ultimate gaming experience. We provide top-tier equipment and professional coaching.',
    matchCenter: language === 'fa' ? 'جدول زنده مسابقات' : 'LIVE ARENA MATCHBOARD',
    tournamentsTitle: language === 'fa' ? 'تورنمنت‌های فعال' : 'ACTIVE TOURNAMENTS',
    stats: language === 'fa' ? 'آمار و ارقام' : 'STATISTICS',
    pricingTitle: language === 'fa' ? 'بسته‌های زمانی' : 'LOUNGE PASSES',
    coachesTitle: language === 'fa' ? 'مربیان حرفه‌ای' : 'PRO COACHES',
    shopTitle: language === 'fa' ? 'فروشگاه تجهیزات' : 'PRO SHOP',
    nextEvent: language === 'fa' ? 'رویداد بعدی' : 'NEXT EVENT',
    toman: language === 'fa' ? 'تومان' : 'Toman',
    address: language === 'fa' ? 'تهران، اتوبان صدر، خیابان شریعتی' : 'Tehran, Sadr Highway, Shariati St.',
    phone: '۰۲۱-۲۲۴۴۶۶۸۸',
    hours: language === 'fa' ? '۲۴ ساعته' : '24/7 Open'
  };

  return (
    <div className="ares-hud-theme relative w-full min-h-screen overflow-x-hidden" dir={isRTL ? 'rtl' : 'ltr'}>
      
      {/* FIXED CYBERPUNK BACKGROUND */}
      <div className="fixed inset-0 z-0">
        <img src="https://images.unsplash.com/photo-1519608487953-e999c86e7455?auto=format&fit=crop&w=2000&q=80" alt="Cyberpunk City" className="w-full h-full object-cover" />
        <div className="absolute inset-0" style={{ background: 'linear-gradient(to bottom, rgba(15,10,30,0.5) 0%, rgba(15,10,30,0.7) 50%, rgba(15,10,30,0.9) 100%)' }} />
        <div className="absolute inset-0 opacity-20" style={{ backgroundImage: 'linear-gradient(rgba(147,51,234,0.1) 1px, transparent 1px), linear-gradient(90deg, rgba(147,51,234,0.1) 1px, transparent 1px)', backgroundSize: '50px 50px' }} />
      </div>

      <div className="relative z-10">
        
        {/* TOP NAVIGATION */}
        <header className="sticky top-0 z-50 p-4">
          <nav className="neon-frame rounded-xl px-4 py-3 max-w-7xl mx-auto">
            <div className="flex items-center justify-between gap-4">
              <div className="flex items-center gap-3 cursor-pointer" onClick={() => onNavigate('home')}>
                <div className="h-9 w-9 text-glow" style={{ color: 'var(--neon-purple)' }}><AresMark /></div>
                <div className="leading-none">
                  <p className="font-bold text-lg tracking-widest text-glow" style={{ fontFamily: 'Orbitron, sans-serif' }}>{t.brandName}</p>
                  <p className="text-[0.6rem] font-semibold tracking-[0.25em]" style={{ color: 'var(--neon-purple)' }}>{t.brandSub}</p>
                </div>
              </div>

              <nav className="hidden lg:flex items-center gap-1">
                {navItems.map(item => (
                  <button key={item.id} onClick={() => { setActiveNav(item.id); onNavigate(item.id); }}
                    className="group flex flex-col items-center gap-1 rounded-lg px-4 py-1.5 transition-colors"
                    style={{ color: activeNav === item.id ? 'var(--neon-purple)' : 'var(--muted-foreground)', background: activeNav === item.id ? 'rgba(147,51,234,0.15)' : 'transparent' }}>
                    <item.icon className={`h-5 w-5 transition-transform group-hover:-translate-y-0.5 ${activeNav === item.id ? 'text-glow' : ''}`} />
                    <span className="text-[0.6rem] font-semibold tracking-widest" style={{ fontFamily: 'Orbitron, sans-serif' }}>{item.label.toUpperCase()}</span>
                  </button>
                ))}
              </nav>

              <div className="flex items-center gap-2">
                <div className="hidden sm:flex items-center gap-1">
                  <button className="ares-icon-btn"><Search className="h-4 w-4" /></button>
                  <button className="ares-icon-btn"><Mail className="h-4 w-4" /></button>
                  <button className="ares-icon-btn relative">
                    <Bell className="h-4 w-4" />
                    <span className="absolute -right-0.5 -top-0.5 h-2 w-2 rounded-full" style={{ background: 'var(--destructive)' }} />
                  </button>
                </div>
                
                <button className="flex items-center gap-2 rounded-lg border px-2 py-1.5 transition-colors hover:bg-white/5" style={{ borderColor: 'var(--border)', background: 'rgba(30,20,50,0.4)' }}>
                  <span className="relative h-8 w-8 overflow-hidden rounded-md" style={{ boxShadow: '0 0 0 1px rgba(147,51,234,0.6)' }}>
                    <img src="https://api.dicebear.com/7.x/avataaars/svg?seed=Player" alt="avatar" className="w-full h-full object-cover" />
                  </span>
                  <span className="hidden sm:block text-left leading-none">
                    <span className="block text-sm font-semibold" style={{ fontFamily: 'Orbitron, sans-serif' }}>PLAYER</span>
                    <span className="block text-xs" style={{ color: 'var(--neon-purple)' }}>Level 42</span>
                  </span>
                  <ChevronDown className="hidden sm:block h-4 w-4" style={{ color: 'var(--muted-foreground)' }} />
                </button>

                <button className="lg:hidden ares-icon-btn" onClick={() => setMobileMenuOpen(!mobileMenuOpen)}><Menu className="h-5 w-5" /></button>
              </div>
            </div>

            {mobileMenuOpen && (
              <nav className="mt-3 grid grid-cols-3 gap-2 border-t pt-3 lg:hidden" style={{ borderColor: 'var(--border)' }}>
                {navItems.map(item => (
                  <button key={item.id} onClick={() => { setActiveNav(item.id); onNavigate(item.id); setMobileMenuOpen(false); }}
                    className="flex flex-col items-center gap-1 rounded-lg px-2 py-2" style={{ color: activeNav === item.id ? 'var(--neon-purple)' : 'var(--muted-foreground)' }}>
                    <item.icon className="h-5 w-5" />
                    <span className="text-[0.6rem] font-semibold tracking-widest" style={{ fontFamily: 'Orbitron, sans-serif' }}>{item.label}</span>
                  </button>
                ))}
              </nav>
            )}
          </nav>
        </header>

        {/* MAIN CONTENT - 3 COLUMNS */}
        <main className="px-4 pb-8">
          <div className="max-w-[1600px] mx-auto grid grid-cols-1 lg:grid-cols-12 gap-4">
            
            {/* LEFT WING */}
            <div className="lg:col-span-3 flex flex-col gap-4">
              
              {/* GAMING STATIONS */}
              <section className="neon-frame rounded-xl p-4">
                <div className="mb-3 flex items-center justify-between">
                  <h2 className="text-sm font-bold tracking-widest text-glow" style={{ fontFamily: 'Orbitron, sans-serif' }}>
                    {language === 'fa' ? 'سیستم‌های گیمینگ' : 'GAMING STATIONS'}
                  </h2>
                  <button onClick={() => onNavigate('reservations')} className="flex items-center gap-1 text-xs font-semibold tracking-wider" style={{ color: 'var(--neon-purple)' }}>
                    {t.viewAll} <ChevronRight className="h-3.5 w-3.5" />
                  </button>
                </div>
                <div className="flex flex-col gap-3">
                  {featuredGames.slice(0, 3).map((game, i) => (
                    <FeaturedGameCard key={game.id || i} game={game} index={i} getLocText={getLocText} onNavigate={onNavigate} />
                  ))}
                </div>
              </section>

              {/* LOUNGE PASSES */}
              <section className="neon-frame rounded-xl p-4">
                <div className="mb-3 flex items-center justify-between">
                  <h2 className="text-sm font-bold tracking-widest text-glow" style={{ fontFamily: 'Orbitron, sans-serif' }}>{t.pricingTitle}</h2>
                  <button onClick={() => onNavigate('reservations')} className="flex items-center gap-1 text-xs font-semibold tracking-wider" style={{ color: 'var(--neon-purple)' }}>
                    {t.viewAll} <ChevronRight className="h-3.5 w-3.5" />
                  </button>
                </div>
                <div className="flex flex-col gap-2">
                  {pricingPackages.map((pkg) => (
                    <div key={pkg.id} className="group flex items-center gap-3 rounded-lg border p-2.5 transition-all cursor-pointer"
                      style={{ borderColor: pkg.popular ? 'var(--neon-gold)' : 'var(--border)', background: pkg.popular ? 'rgba(234,179,8,0.1)' : 'rgba(30,20,50,0.2)' }}
                      onClick={() => onNavigate('reservations')}>
                      <span className="grid h-10 w-10 shrink-0 place-items-center rounded-md border"
                        style={{ borderColor: pkg.popular ? 'var(--neon-gold)' : 'var(--neon-purple)', color: pkg.popular ? 'var(--neon-gold)' : 'var(--neon-purple)' }}>
                        <Hexagon className="h-5 w-5" />
                      </span>
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-sm font-bold tracking-wide" style={{ fontFamily: 'Orbitron, sans-serif' }}>{getLocText(pkg.title)}</p>
                        <p className="text-xs" style={{ color: 'var(--muted-foreground)' }}>{getLocText(pkg.duration)}</p>
                      </div>
                      <div className="text-right leading-none">
                        <p className="text-sm font-bold" style={{ fontFamily: 'Orbitron, sans-serif', color: pkg.popular ? 'var(--neon-gold)' : 'var(--neon-purple)' }}>{pkg.price.toLocaleString()}</p>
                        <p className="text-[0.55rem] tracking-widest" style={{ color: 'var(--muted-foreground)' }}>{t.toman}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </section>

              {/* PRO COACHES */}
              <section className="neon-frame rounded-xl p-4">
                <div className="mb-3"><h2 className="text-sm font-bold tracking-widest text-glow" style={{ fontFamily: 'Orbitron, sans-serif' }}>{t.coachesTitle}</h2></div>
                <div className="flex flex-col gap-2">
                  {staffTeam.map((staff) => (
                    <div key={staff.id} className="group flex items-center gap-3 rounded-lg border p-2.5 transition-all" style={{ borderColor: 'var(--border)', background: 'rgba(15,10,30,0.5)' }}>
                      <div className="relative h-10 w-10 shrink-0">
                        <img src={staff.avatar} alt={getLocText(staff.name)} className="w-full h-full rounded-full object-cover" style={{ boxShadow: '0 0 0 2px var(--neon-purple)' }} />
                        <span className="absolute -bottom-0.5 left-1/2 -translate-x-1/2 px-1 py-0 text-[0.4rem] font-bold rounded" style={{ background: 'var(--neon-gold)', color: 'black', fontFamily: 'Orbitron, sans-serif' }}>PRO</span>
                      </div>
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-sm font-bold tracking-wide" style={{ fontFamily: 'Orbitron, sans-serif' }}>{getLocText(staff.name)}</p>
                        <p className="text-[0.6rem]" style={{ color: 'var(--neon-purple)' }}>@{staff.gamerTag} • {getLocText(staff.role)}</p>
                      </div>
                      <span className="text-[0.55rem] px-2 py-0.5 rounded" style={{ background: 'rgba(34,211,238,0.1)', border: '1px solid rgba(34,211,238,0.3)', color: 'var(--neon-cyan)' }}>{staff.specialty}</span>
                    </div>
                  ))}
                </div>
              </section>

              {/* CONTACT US */}
              <section className="neon-frame rounded-xl p-4 flex-1 flex flex-col">
                <div className="mb-3 flex items-center justify-between">
                  <h2 className="text-sm font-bold tracking-widest text-glow" style={{ fontFamily: 'Orbitron, sans-serif' }}>{language === 'fa' ? 'ارسال تیکت' : 'CONTACT US'}</h2>
                  <Mail className="h-4 w-4" style={{ color: 'var(--neon-cyan)' }} />
                </div>
                <form className="flex flex-col gap-3 flex-1" onSubmit={(e) => e.preventDefault()}>
                  <div><label className="block text-[0.6rem] font-semibold tracking-widest mb-1" style={{ color: 'var(--muted-foreground)' }}>{language === 'fa' ? 'نام شما' : 'YOUR NAME'}</label>
                    <input type="text" placeholder={language === 'fa' ? 'نام و نام خانوادگی...' : 'Enter your name...'} className="ares-input text-sm" /></div>
                  <div><label className="block text-[0.6rem] font-semibold tracking-widest mb-1" style={{ color: 'var(--muted-foreground)' }}>{language === 'fa' ? 'ایمیل' : 'EMAIL'}</label>
                    <input type="email" placeholder="email@example.com" className="ares-input text-sm" /></div>
                  <div><label className="block text-[0.6rem] font-semibold tracking-widest mb-1" style={{ color: 'var(--muted-foreground)' }}>{language === 'fa' ? 'موضوع' : 'SUBJECT'}</label>
                    <input type="text" placeholder={language === 'fa' ? 'موضوع پیام...' : 'Ticket subject...'} className="ares-input text-sm" /></div>
                  <div className="flex-1 flex flex-col"><label className="block text-[0.6rem] font-semibold tracking-widest mb-1" style={{ color: 'var(--muted-foreground)' }}>{language === 'fa' ? 'متن پیام' : 'MESSAGE'}</label>
                    <textarea rows={4} placeholder={language === 'fa' ? 'پیام خود را بنویسید...' : 'Write your message...'} className="ares-input text-sm flex-1 resize-none" /></div>
                  <button type="submit" className="ares-btn ares-btn-primary w-full"><Mail className="h-4 w-4" />{language === 'fa' ? 'ارسال تیکت' : 'SEND TICKET'}</button>
                </form>
              </section>
            </div>

            {/* CENTER */}
            <div className="lg:col-span-6 flex flex-col gap-4">
              
              {/* HERO */}
              <section className="neon-frame rounded-xl overflow-hidden">
                <div className="relative h-[300px] md:h-[400px]">
                  <img src={featuredGames[activeBanner]?.imageUrl} alt="Hero" className="w-full h-full object-cover transition-opacity duration-1000" />
                  <div className="absolute inset-0" style={{ background: 'linear-gradient(to top, rgba(15,10,30,0.95) 0%, rgba(15,10,30,0.3) 50%, transparent 100%)' }} />
                  <div className="absolute inset-0 flex flex-col items-center justify-center text-center p-6">
                    <div className="flex items-center gap-4 mb-4">
                      <div className="h-[1px] w-12" style={{ background: 'var(--neon-gold)' }}></div>
                      <span className="uppercase tracking-widest text-xs font-black" style={{ color: 'var(--neon-gold)', fontFamily: 'Orbitron, sans-serif' }}>{t.brandName}</span>
                      <div className="h-[1px] w-12" style={{ background: 'var(--neon-gold)' }}></div>
                    </div>
                    <h1 className="text-4xl md:text-6xl font-black uppercase tracking-tighter mb-4 text-glow" style={{ fontFamily: 'Orbitron, sans-serif' }}>
                      <span style={{ color: 'var(--foreground)' }}>{t.heroTitle}</span> <span style={{ color: 'var(--neon-purple)' }}>{t.heroBrand}</span>
                    </h1>
                    <p className="text-sm md:text-base mb-6 max-w-lg" style={{ color: 'var(--muted-foreground)' }}>{t.heroDesc}</p>
                    <button onClick={() => onNavigate('reservations')} className="ares-btn ares-btn-primary"><Play className="h-4 w-4" /> {t.bookNow}</button>
                  </div>
                  <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-2">
                    {featuredGames.map((_, idx) => (
                      <button key={idx} onClick={() => setActiveBanner(idx)} className="w-2 h-2 rounded-full transition-all"
                        style={{ background: idx === activeBanner ? 'var(--neon-purple)' : 'var(--secondary)', boxShadow: idx === activeBanner ? '0 0 10px var(--neon-purple)' : 'none' }} />
                    ))}
                  </div>
                </div>
                <div className="px-6 py-4 flex items-center justify-center gap-6" style={{ background: 'rgba(15,10,30,0.8)' }}>
                  <div className="flex items-center gap-2">
                    <Clock className="h-5 w-5" style={{ color: 'var(--neon-cyan)' }} />
                    <span className="text-xs font-semibold tracking-widest" style={{ fontFamily: 'Orbitron, sans-serif', color: 'var(--muted-foreground)' }}>{t.nextEvent}</span>
                  </div>
                  <div className="flex gap-4">
                    {[{ value: timeLeft.days, label: 'DAYS' }, { value: timeLeft.hours, label: 'HRS' }, { value: timeLeft.mins, label: 'MIN' }, { value: timeLeft.secs, label: 'SEC' }].map((item, i) => (
                      <div key={i} className="text-center">
                        <div className="text-xl font-bold text-glow" style={{ fontFamily: 'Orbitron, sans-serif', color: 'var(--neon-purple)' }}>{padZero(item.value)}</div>
                        <div className="text-[0.5rem] tracking-widest" style={{ color: 'var(--muted-foreground)' }}>{item.label}</div>
                      </div>
                    ))}
                  </div>
                </div>
              </section>

              {/* SERVICE SHORTCUTS */}
              <section className="neon-frame rounded-xl p-4">
                <div className="flex flex-wrap justify-center gap-4 md:gap-6">
                  {loungeSections.map((section, idx) => {
                    const icons = [Monitor, Gamepad2, Coffee, ShoppingBag, Trophy];
                    const Icon = icons[idx % icons.length];
                    return (
                      <div key={section.id} onClick={() => onNavigate(section.id === 'consoles' ? 'reservations' : section.id)} className="flex flex-col items-center gap-2 group cursor-pointer w-20 md:w-24">
                        <div className="w-14 h-14 md:w-16 md:h-16 rounded-full flex items-center justify-center transition-all duration-300 group-hover:scale-110" style={{ background: 'rgba(15,10,30,0.8)', border: '2px solid var(--border)' }}>
                          <Icon className="w-6 h-6 md:w-7 md:h-7" style={{ color: idx === 0 ? 'var(--neon-purple)' : 'var(--muted-foreground)' }} />
                        </div>
                        <span className="text-[0.6rem] md:text-[0.65rem] font-bold uppercase tracking-wider text-center" style={{ fontFamily: 'Orbitron, sans-serif', color: 'var(--muted-foreground)' }}>{getLocText(section.name).split(' ')[0]}</span>
                      </div>
                    );
                  })}
                </div>
              </section>

              {/* ABOUT + STATS */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <section className="neon-frame rounded-xl p-4">
                  <h3 className="text-sm font-bold tracking-widest text-glow mb-3" style={{ fontFamily: 'Orbitron, sans-serif' }}>{t.aboutTitle}</h3>
                  <p className="text-sm leading-relaxed mb-4" style={{ color: 'var(--muted-foreground)' }}>{t.aboutDesc}</p>
                  <button onClick={() => onNavigate('about')} className="ares-btn w-full">{language === 'fa' ? 'بیشتر بدانید' : 'LEARN MORE'} <ArrowRight className="h-4 w-4" /></button>
                </section>
                <section className="neon-frame rounded-xl p-4">
                  <h3 className="text-sm font-bold tracking-widest text-glow mb-3" style={{ fontFamily: 'Orbitron, sans-serif' }}>{t.stats}</h3>
                  <div className="grid grid-cols-2 gap-3">
                    {[
                      { icon: Users, value: '5000+', label: language === 'fa' ? 'گیمر' : 'Gamers', color: 'var(--neon-cyan)' },
                      { icon: Monitor, value: '50+', label: language === 'fa' ? 'سیستم' : 'Rigs', color: 'var(--neon-purple)' },
                      { icon: Trophy, value: '200+', label: language === 'fa' ? 'تورنمنت' : 'Events', color: 'var(--neon-gold)' },
                      { icon: Award, value: '99%', label: language === 'fa' ? 'رضایت' : 'Rating', color: 'var(--neon-cyan)' }
                    ].map((stat, i) => (
                      <div key={i} className="text-center p-2 rounded-lg" style={{ background: 'rgba(15,10,30,0.5)' }}>
                        <stat.icon className="h-5 w-5 mx-auto mb-1" style={{ color: stat.color }} />
                        <div className="text-lg font-black" style={{ fontFamily: 'Orbitron, sans-serif', color: stat.color }}>{stat.value}</div>
                        <div className="text-[0.55rem] tracking-widest" style={{ color: 'var(--muted-foreground)' }}>{stat.label}</div>
                      </div>
                    ))}
                  </div>
                </section>
              </div>
            </div>

            {/* RIGHT WING */}
            <div className="lg:col-span-3 flex flex-col gap-4">
              
              {/* TOURNAMENTS */}
              <section className="neon-frame rounded-xl p-4">
                <div className="mb-3 flex items-center justify-between">
                  <h2 className="text-sm font-bold tracking-widest text-glow" style={{ fontFamily: 'Orbitron, sans-serif' }}>{t.tournamentsTitle}</h2>
                  <button onClick={() => onNavigate('tournaments')} className="flex items-center gap-1 text-xs font-semibold tracking-wider" style={{ color: 'var(--neon-purple)' }}>{t.viewAll} <ChevronRight className="h-3.5 w-3.5" /></button>
                </div>
                <div className="flex flex-col gap-3">
                  {tournaments.map((tournament, i) => (<TournamentCard key={tournament.id} tournament={tournament} index={i} onNavigate={onNavigate} language={language} />))}
                </div>
              </section>

              {/* MATCH CENTER */}
              <section className="neon-frame rounded-xl p-4">
                <div className="mb-3 flex items-center justify-between">
                  <h2 className="text-sm font-bold tracking-widest text-glow" style={{ fontFamily: 'Orbitron, sans-serif' }}>{t.matchCenter}</h2>
                  <span className="ares-badge-live text-[0.5rem]"><span className="w-1.5 h-1.5 rounded-full animate-pulse" style={{ background: '#ef4444' }} />LIVE</span>
                </div>
                <div className="space-y-3">
                  {matchHistory.map(match => (
                    <div key={match.id} className="p-3 rounded-lg border transition-all" style={{ borderColor: match.status === 'Live' ? 'rgba(239,68,68,0.5)' : 'var(--border)', background: 'rgba(15,10,30,0.5)' }}>
                      <div className="flex items-center justify-between mb-2">
                        <span className={`text-[0.5rem] font-bold px-2 py-0.5 rounded ${match.status === 'Live' ? 'ares-badge-live' : match.status === 'Scheduled' ? 'ares-badge-gold' : 'ares-badge'}`}>{match.game}</span>
                        <span className="text-[0.55rem] tracking-widest truncate ml-2" style={{ color: 'var(--muted-foreground)' }}>{getLocText(match.title)}</span>
                      </div>
                      <div className="flex items-center justify-between text-sm">
                        <span className="font-semibold truncate flex-1">{match.teamA}</span>
                        <div className="px-3 py-1 rounded mx-2" style={{ background: 'var(--secondary)' }}>
                          <span className="font-bold" style={{ fontFamily: 'Orbitron, sans-serif', color: 'var(--neon-cyan)' }}>{match.scoreA}</span>
                          <span className="mx-1" style={{ color: 'var(--muted-foreground)' }}>:</span>
                          <span className="font-bold" style={{ fontFamily: 'Orbitron, sans-serif', color: 'var(--neon-purple)' }}>{match.scoreB}</span>
                        </div>
                        <span className="font-semibold truncate flex-1 text-right">{match.teamB}</span>
                      </div>
                      <div className="text-center mt-2"><span className="text-[0.55rem]" style={{ color: match.status === 'Live' ? '#ef4444' : 'var(--muted-foreground)' }}>{match.time}</span></div>
                    </div>
                  ))}
                </div>
              </section>

              {/* PRO SHOP */}
              <section className="neon-frame rounded-xl p-4 flex-1 flex flex-col">
                <div className="mb-3 flex items-center justify-between">
                  <h2 className="text-sm font-bold tracking-widest text-glow" style={{ fontFamily: 'Orbitron, sans-serif' }}>{t.shopTitle}</h2>
                  <button onClick={() => onNavigate('shop')} className="flex items-center gap-1 text-xs font-semibold tracking-wider" style={{ color: 'var(--neon-purple)' }}>{t.viewAll} <ChevronRight className="h-3.5 w-3.5" /></button>
                </div>
                <div className="grid grid-cols-2 gap-2 flex-1">
                  {[
                    { name: language === 'fa' ? 'هدست' : 'Headset', icon: '🎧' },
                    { name: language === 'fa' ? 'ماوس' : 'Mouse', icon: '🖱️' },
                    { name: language === 'fa' ? 'کیبورد' : 'Keyboard', icon: '⌨️' },
                    { name: language === 'fa' ? 'صندلی' : 'Chair', icon: '🪑' },
                    { name: language === 'fa' ? 'مانیتور' : 'Monitor', icon: '🖥️' },
                    { name: language === 'fa' ? 'کنترلر' : 'Controller', icon: '🎮' }
                  ].map((item, i) => (
                    <div key={i} className="rounded-lg flex items-center justify-center cursor-pointer transition-all hover:scale-105 min-h-[70px]" style={{ background: 'rgba(15,10,30,0.5)', border: '1px solid var(--border)' }} onClick={() => onNavigate('shop')}>
                      <div className="text-center"><span className="text-xl block mb-1">{item.icon}</span><span className="text-[0.6rem] font-semibold" style={{ color: 'var(--muted-foreground)' }}>{item.name}</span></div>
                    </div>
                  ))}
                </div>
              </section>
            </div>
          </div>
        </main>

        {/* FOOTER */}
        <footer className="px-4 pb-4">
          <div className="max-w-7xl mx-auto neon-frame rounded-xl p-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 text-glow" style={{ color: 'var(--neon-purple)' }}><AresMark /></div>
                <div>
                  <p className="font-bold text-lg tracking-widest text-glow" style={{ fontFamily: 'Orbitron, sans-serif' }}>{t.brandName}</p>
                  <p className="text-[0.6rem] tracking-[0.2em]" style={{ color: 'var(--neon-purple)' }}>{t.brandSub}</p>
                </div>
              </div>
              <div className="flex flex-col gap-2">
                <div className="flex items-center gap-2"><MapPin className="h-4 w-4" style={{ color: 'var(--neon-cyan)' }} /><span className="text-sm" style={{ color: 'var(--muted-foreground)' }}>{t.address}</span></div>
                <div className="flex items-center gap-2"><Phone className="h-4 w-4" style={{ color: 'var(--neon-cyan)' }} /><span className="text-sm" style={{ color: 'var(--muted-foreground)' }}>{t.phone}</span></div>
                <div className="flex items-center gap-2"><Clock className="h-4 w-4" style={{ color: 'var(--neon-cyan)' }} /><span className="text-sm" style={{ color: 'var(--muted-foreground)' }}>{t.hours}</span></div>
              </div>
              <div className="flex items-center justify-end gap-4">
                <Wifi className="h-4 w-4" style={{ color: 'var(--neon-cyan)' }} />
                <Volume2 className="h-4 w-4" style={{ color: 'var(--muted-foreground)' }} />
                <Settings className="h-4 w-4" style={{ color: 'var(--muted-foreground)' }} />
                <span className="text-sm font-bold" style={{ fontFamily: 'Orbitron, sans-serif' }}>{currentTime || '--:--'}</span>
              </div>
            </div>
            <div className="mt-4 pt-4 text-center" style={{ borderTop: '1px solid var(--border)' }}>
              <p className="text-xs" style={{ color: 'var(--muted-foreground)' }}>© 2025 {t.brandName} Gaming Lounge. <span className="text-glow" style={{ color: 'var(--neon-purple)' }}>ARES</span> Theme</p>
            </div>
          </div>
        </footer>
      </div>
    </div>
  );
}

// ==========================================
// SUB-COMPONENTS
// ==========================================

function FeaturedGameCard({ game, index, getLocText, onNavigate }: { game: FeaturedGame; index: number; getLocText: (obj: LocalizedText | undefined) => string; onNavigate: (tab: string) => void; }) {
  const accents = ['var(--neon-gold)', 'var(--neon-purple)', 'var(--neon-cyan)'];
  const accent = accents[index % accents.length];
  const rarities = ['LEGENDARY', 'EPIC', 'RARE'];
  const rarity = rarities[index % rarities.length];

  return (
    <button type="button" onClick={() => onNavigate('reservations')} className="group relative rounded-xl p-[2px] text-left transition-all duration-300 hover:-translate-y-0.5 w-full" style={{ background: `linear-gradient(150deg, color-mix(in oklch, ${accent} 85%, transparent), transparent 45%, color-mix(in oklch, ${accent} 55%, transparent))`, boxShadow: `0 0 22px -8px ${accent}, 0 14px 24px -16px rgba(0,0,0,0.9)` }}>
      <span className="pointer-events-none absolute inset-[2px] rounded-[10px] bg-gradient-to-b from-white/10 to-transparent" />
      <div className="relative overflow-hidden rounded-[10px]" style={{ background: 'rgba(15,10,30,0.85)' }}>
        <div className="relative h-24 w-full overflow-hidden">
          <img src={game.imageUrl} alt={getLocText(game.title)} className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110" />
          <span className="pointer-events-none absolute inset-x-0 top-0 h-1/2 bg-gradient-to-b from-white/20 to-transparent" />
          <span className="pointer-events-none absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
          <span className="absolute right-2 top-2 flex gap-0.5">{[1,2,3,4,5].map((_, i) => <Star key={i} className="h-2.5 w-2.5" style={{ fill: 'var(--neon-gold)', color: 'var(--neon-gold)' }} />)}</span>
          <span className="absolute right-2 top-1/2 grid h-8 w-8 -translate-y-1/2 translate-x-2 place-items-center rounded-md border opacity-0 transition-all duration-300 group-hover:translate-x-0 group-hover:opacity-100" style={{ borderColor: accent, color: accent, boxShadow: `0 0 16px -4px ${accent}` }}><Play className="h-3.5 w-3.5 fill-current" /></span>
          <div className="absolute bottom-1 left-2 right-2">
            <p className="text-sm font-bold leading-none tracking-wide truncate" style={{ fontFamily: 'Orbitron, sans-serif' }}>{getLocText(game.title)}</p>
            <p className="text-[0.55rem] font-bold tracking-[0.2em]" style={{ color: accent }}>{rarity}</p>
          </div>
        </div>
        <div className="flex items-center justify-between gap-1 px-2 py-1.5">
          <StatIcon icon={Swords} value={1200 - index * 100} color="var(--neon-cyan)" />
          <span className="h-3 w-px" style={{ background: 'var(--border)' }} />
          <StatIcon icon={Shield} value={850 - index * 50} color="var(--neon-purple)" />
          <span className="h-3 w-px" style={{ background: 'var(--border)' }} />
          <StatIcon icon={Heart} value={1100 - index * 75} color="var(--destructive)" />
        </div>
      </div>
    </button>
  );
}

function TournamentCard({ tournament, index, onNavigate, language }: { tournament: Tournament; index: number; onNavigate: (tab: string) => void; language: string; }) {
  const accents = ['var(--neon-cyan)', 'var(--neon-gold)', 'var(--neon-purple)'];
  const accent = accents[index % accents.length];
  const images = ['https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=400&q=80', 'https://images.unsplash.com/photo-1606144042614-b2417e99c4e3?auto=format&fit=crop&w=400&q=80', 'https://images.unsplash.com/photo-1511512578047-dfb367046420?auto=format&fit=crop&w=400&q=80'];

  return (
    <button type="button" onClick={() => onNavigate('tournaments')} className="group relative rounded-xl p-[2px] text-left transition-all duration-300 hover:-translate-y-0.5 w-full" style={{ background: `linear-gradient(150deg, color-mix(in oklch, ${accent} 85%, transparent), transparent 45%, color-mix(in oklch, ${accent} 55%, transparent))`, boxShadow: `0 0 22px -8px ${accent}, 0 14px 24px -16px rgba(0,0,0,0.9)` }}>
      <span className="pointer-events-none absolute inset-[2px] rounded-[10px] bg-gradient-to-b from-white/10 to-transparent" />
      <div className="relative overflow-hidden rounded-[10px]" style={{ background: 'rgba(15,10,30,0.85)' }}>
        <div className="relative h-24 w-full overflow-hidden">
          <img src={images[index % images.length]} alt={tournament.title} className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110" />
          <span className="pointer-events-none absolute inset-x-0 top-0 h-1/2 bg-gradient-to-b from-white/20 to-transparent" />
          <span className="pointer-events-none absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
          <span className={`absolute left-2 top-2 text-[0.5rem] font-bold px-2 py-0.5 rounded ${tournament.status === 'Active' ? 'ares-badge-live' : tournament.status === 'Upcoming' ? 'ares-badge-gold' : 'ares-badge'}`}>{tournament.status === 'Active' ? (language === 'fa' ? 'فعال' : 'ACTIVE') : tournament.status === 'Upcoming' ? (language === 'fa' ? 'ثبت‌نام' : 'OPEN') : (language === 'fa' ? 'پایان' : 'DONE')}</span>
          <span className="absolute right-2 top-2 text-[0.5rem] font-bold px-2 py-0.5 rounded ares-badge-cyan">{tournament.game}</span>
          <div className="absolute bottom-1 left-2 right-2">
            <p className="text-sm font-bold leading-none tracking-wide truncate" style={{ fontFamily: 'Orbitron, sans-serif' }}>{tournament.title}</p>
            <p className="text-[0.55rem] font-bold tracking-[0.2em]" style={{ color: accent }}>{tournament.startDate}</p>
          </div>
        </div>
        <div className="flex items-center justify-between gap-1 px-2 py-1.5">
          <div className="flex-1 text-center"><p className="text-[0.5rem] tracking-widest" style={{ color: 'var(--muted-foreground)' }}>{language === 'fa' ? 'جایزه' : 'PRIZE'}</p><p className="text-xs font-bold" style={{ fontFamily: 'Orbitron, sans-serif', color: 'var(--neon-gold)' }}>{tournament.prizePool ? `${(tournament.prizePool / 1000000).toFixed(1)}M` : '---'}</p></div>
          <span className="h-3 w-px" style={{ background: 'var(--border)' }} />
          <div className="flex-1 text-center"><p className="text-[0.5rem] tracking-widest" style={{ color: 'var(--muted-foreground)' }}>{language === 'fa' ? 'تیم‌ها' : 'TEAMS'}</p><p className="text-xs font-bold" style={{ fontFamily: 'Orbitron, sans-serif', color: 'var(--neon-cyan)' }}>{tournament.registeredTeamsCount}/{tournament.maxTeams}</p></div>
          <span className="h-3 w-px" style={{ background: 'var(--border)' }} />
          <div className="flex-1 text-center"><p className="text-[0.5rem] tracking-widest" style={{ color: 'var(--muted-foreground)' }}>{language === 'fa' ? 'ورودی' : 'FEE'}</p><p className="text-xs font-bold" style={{ fontFamily: 'Orbitron, sans-serif', color: 'var(--neon-purple)' }}>{(tournament.registrationFee / 1000)}K</p></div>
        </div>
      </div>
    </button>
  );
}

function StatIcon({ icon: Icon, value, color }: { icon: React.ComponentType<{ className?: string; style?: React.CSSProperties }>; value: number; color: string; }) {
  return (<span className="flex flex-1 items-center justify-center gap-1"><Icon className="h-3 w-3" style={{ color }} /><span className="text-[0.65rem] font-semibold tabular-nums" style={{ fontFamily: 'Orbitron, sans-serif' }}>{value}</span></span>);
}
