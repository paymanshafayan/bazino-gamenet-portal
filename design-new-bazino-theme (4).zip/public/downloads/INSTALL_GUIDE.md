# 🎮 ARES HUD Theme - نصب قالب

## 📦 فایل‌های قالب

| فایل | مسیر نصب |
|------|----------|
| `AresHudHome.tsx` | `src/components/AresHudHome.tsx` |
| `ares-hud-theme.css` | اضافه به `src/index.css` |

---

## 🔧 مراحل نصب

### مرحله ۱: کپی فایل کامپوننت

```bash
cp AresHudHome.tsx /path/to/bazino/src/components/
```

### مرحله ۲: اضافه کردن CSS

محتوای فایل `ares-hud-theme.css` را به انتهای فایل `src/index.css` اضافه کنید.

### مرحله ۳: ثبت قالب در App.tsx

در آرایه `availableThemes` اضافه کنید:

```tsx
{
  id: 'ares-hud',
  name: {
    fa: 'آرس HUD',
    en: 'Ares HUD',
    ru: 'Арес ХУД',
    tr: 'Ares HUD'
  },
  description: {
    fa: 'قالب سایبرپانک با افکت‌های شیشه‌ای و نئونی',
    en: 'Cyberpunk theme with glass morphism and neon effects',
    ru: 'Киберпанк тема со стеклянными эффектами',
    tr: 'Cam efektleri ve neon detaylarıyla siber punk tema'
  },
  preview: '/themes/ares-hud-preview.png',
  primaryColor: '#9333ea',
  accentColor: '#22d3ee'
}
```

### مرحله ۴: اضافه کردن شرط رندر در HomeTab.tsx

قبل از `return` اصلی:

```tsx
if (themeId === 'ares-hud') {
  return (
    <AresHudHome
      featuredGames={activeBanners}
      matchHistory={matchHistory}
      pricingPackages={pricingPackages}
      loungeSections={loungeSections}
      tournaments={tournaments}
      staffTeam={staffTeam}
      onNavigate={onNavigate}
      language={language}
    />
  );
}
```

### مرحله ۵: Import کامپوننت

در بالای HomeTab.tsx:

```tsx
import AresHudHome from './AresHudHome';
```

### مرحله ۶: فونت‌ها

در `index.html`:

```html
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;500;600;700;800;900&family=Rajdhani:wght@300;400;500;600;700&display=swap" rel="stylesheet">
```

---

## 🎨 رنگ‌بندی

| رنگ | مقدار | استفاده |
|-----|-------|---------|
| Neon Purple | `#9333ea` | رنگ اصلی، دکمه‌ها |
| Neon Cyan | `#22d3ee` | آیکون‌ها، هایلایت |
| Neon Gold | `#eab308` | ستاره‌ها، بج‌ها |
| Background | `#0f0a1e` | پس‌زمینه |

---

## 📐 بخش‌های قالب

1. **Hero Section** - اسلایدر با تایمر معکوس
2. **Service Shortcuts** - میانبرهای لانژ
3. **Gaming Stations** - کارت‌های سیستم
4. **About + Stats** - آمار کلوپ
5. **Match Center** - جدول مسابقات زنده
6. **Tournaments** - تورنمنت‌های فعال
7. **Pricing** - بسته‌های قیمت
8. **Pro Coaches** - مربیان
9. **Contact Form** - فرم تیکت
10. **Pro Shop** - فروشگاه
11. **Footer** - فوتر

---

## ✅ آماده استفاده!

پس از نصب، قالب "Ares HUD" را از انتخابگر قالب انتخاب کنید.

---

**نسخه:** 1.0.0  
**سازگار با:** Bazino Pro v2.x
