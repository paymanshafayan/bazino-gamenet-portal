# 🎮 ARES HUD Theme - راهنمای نصب (سیستم جدید)

## 📦 فایل‌های قالب

| فایل | مسیر نصب |
|------|----------|
| `ares-hud.css` | `src/themes/ares-hud.css` |

---

## 🔧 مراحل نصب

### مرحله ۱: کپی فایل CSS

فایل `ares-hud.css` را در پوشه `src/themes/` قرار دهید:

```bash
cp ares-hud.css /path/to/bazino/src/themes/
```

### مرحله ۲: ثبت قالب در index.ts

در فایل `src/themes/index.ts`، قالب را به آرایه `BUILT_IN_THEMES` اضافه کنید:

```typescript
export const BUILT_IN_THEMES: ThemeInfo[] = [
  { id: 'dark-gold', name: 'Dark Gold', type: 'built-in' },
  { id: 'cyberpunk-cyan', name: 'Cyberpunk Cyan', type: 'built-in' },
  { id: 'geco-purple', name: 'Geco Purple', type: 'built-in' },
  { id: 'gaming-amp', name: 'Gaming AMP', type: 'built-in' },
  { id: 'console-grid', name: 'قالب گرید کنسولی (کلاسیک)', type: 'built-in' },
  // ✅ قالب جدید
  { id: 'ares-hud', name: 'Ares HUD', type: 'built-in' }
];
```

### مرحله ۳: فونت‌ها (اختیاری)

اگر فونت‌ها لود نشدند، در `index.html` اضافه کنید:

```html
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;500;600;700;800;900&family=Rajdhani:wght@300;400;500;600;700&display=swap" rel="stylesheet">
```

### مرحله ۴: (اختیاری) اضافه کردن پیش‌نمایش

در فایل `ThemeScreenshot.tsx` رنگ‌های پیش‌نمایش را اضافه کنید:

```typescript
const themeColors: Record<string, { primary: string; bg: string; accent: string }> = {
  // ... قالب‌های قبلی
  'ares-hud': { 
    primary: '#a855f7',  // بنفش نئونی
    bg: '#0f0a1e',       // پس‌زمینه تیره
    accent: '#22d3ee'    // سیان نئونی
  }
};
```

---

## ✅ تمام!

قالب به‌صورت خودکار توسط موتور قالب‌بندی Bazino بارگذاری می‌شود.

از انتخابگر قالب در سایت، "Ares HUD" را انتخاب کنید.

---

## 🎨 ویژگی‌های قالب

### رنگ‌بندی
| رنگ | کد | استفاده |
|-----|-----|---------|
| Neon Purple | `#a855f7` | رنگ اصلی، دکمه‌ها، هایلایت |
| Neon Cyan | `#22d3ee` | آیکون‌ها، حاشیه‌ها |
| Neon Gold | `#eab308` | ستاره‌ها، بج‌های ویژه |
| Background | `#0f0a1e` | پس‌زمینه تیره |

### استایل‌های خاص
- **Glass Morphism**: پنل‌های شیشه‌ای با blur
- **Gradient Rim**: حاشیه‌های گرادیان سیان-بنفش
- **Text Glow**: افکت درخشش متن
- **Neon Buttons**: دکمه‌های نئونی با hover glow
- **Grid Background**: پس‌زمینه شطرنجی سایبرپانک

### فونت‌ها
- **Orbitron**: تیترها و لیبل‌ها
- **Rajdhani**: متن بدنه
- **Vazirmatn**: متن فارسی

---

## 📐 صفحات پوشش‌داده شده

✅ صفحه اصلی (Home)
✅ رزرو سیستم (Reservations)
✅ کافه/بوفه (Cafe)
✅ فروشگاه (Shop)
✅ مسابقات (Tournaments)
✅ باشگاه مشتریان (Loyalty)
✅ وبلاگ (Blog)
✅ چت (Chat)
✅ پنل ادمین (Admin)
✅ مودال‌ها
✅ فرم‌ها
✅ جداول

---

## ⚠️ نکات

1. فایل CSS باید در پوشه `src/themes/` باشد
2. نام فایل باید با `id` قالب یکی باشد: `ares-hud.css`
3. استایل‌ها با کلاس `.theme-ares-hud` اسکوپ شده‌اند
4. متغیرهای رنگی با `body[data-theme='ares-hud']` تعریف شده‌اند

---

**نسخه:** 1.0.0  
**سازگار با:** Bazino Pro v2.x (سیستم قالب‌بندی جدید)
