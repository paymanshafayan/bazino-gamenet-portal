import AresHudHome from './components/AresHudHome';

export default function App() {
  // Demo navigation handler
  const handleNavigate = (tab: string) => {
    console.log('Navigate to:', tab);
    // In Bazino integration, this would call the actual navigation
  };

  return (
    <AresHudHome 
      language="en"
      onNavigate={handleNavigate}
    />
  );
}
