interface EdgeCurveProps {
  position: "top" | "bottom";
}

export default function EdgeCurve({ position }: EdgeCurveProps) {
  const flip = position === "bottom";
  return (
    <svg
      className={`pointer-events-none absolute left-0 w-full ${flip ? "bottom-0 rotate-180" : "top-0"}`}
      style={{ height: "70px" }}
      viewBox="0 0 1600 90"
      preserveAspectRatio="none"
      fill="none"
    >
      <path
        d="M0,18 C160,18 260,78 430,78 C500,78 495,10 560,10 L1040,10 C1105,10 1100,78 1170,78 C1340,78 1440,18 1600,18"
        stroke="url(#edgeGradient)"
        strokeWidth="2"
        fill="none"
        style={{ filter: "drop-shadow(0 0 6px rgba(179,102,255,0.9))" }}
      />
      <path
        d="M0,18 C160,18 260,78 430,78 C500,78 495,10 560,10 L1040,10 C1105,10 1100,78 1170,78 C1340,78 1440,18 1600,18"
        stroke="url(#edgeGradient2)"
        strokeWidth="6"
        fill="none"
        opacity="0.25"
        style={{ filter: "blur(3px)" }}
      />
      <defs>
        <linearGradient id="edgeGradient" x1="0" y1="0" x2="1600" y2="0" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#ffcf5c" />
          <stop offset="25%" stopColor="#b366ff" />
          <stop offset="50%" stopColor="#7dd3fc" />
          <stop offset="75%" stopColor="#b366ff" />
          <stop offset="100%" stopColor="#ffcf5c" />
        </linearGradient>
        <linearGradient id="edgeGradient2" x1="0" y1="0" x2="1600" y2="0" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#ffcf5c" />
          <stop offset="50%" stopColor="#b366ff" />
          <stop offset="100%" stopColor="#ffcf5c" />
        </linearGradient>
      </defs>
    </svg>
  );
}
