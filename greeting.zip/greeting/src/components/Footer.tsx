import { MessageSquare, Bell, Image as ImageIcon, Settings } from "lucide-react";
import { useState } from "react";
import EdgeCurve from "./EdgeCurve";

export default function Footer() {
  const [tab, setTab] = useState<"GLOBAL" | "TEAM">("GLOBAL");

  return (
    <footer className="absolute bottom-0 left-0 z-30 w-full">
      <EdgeCurve position="bottom" />

      {/* Book a PC - sits on the peak of the curve */}
      <div className="absolute bottom-9 left-1/2 z-20 -translate-x-1/2">
        <button className="font-display neon-border-glow animate-pulse-glow rounded-full border border-amber-300/60 bg-gradient-to-b from-amber-300/90 to-purple-500/80 px-8 py-2.5 text-xs font-bold tracking-widest text-slate-950 shadow-lg transition hover:scale-105 sm:text-sm">
          BOOK A PC
        </button>
      </div>

      {/* Chat box bottom-left */}
      <div className="absolute bottom-0 left-45 z-10 hidden w-56 rounded-xl p-2 sm:block md:w-64">
        <div className="mb-1.5 flex gap-3 text-[10px] font-semibold tracking-wide">
          {(["GLOBAL", "TEAM"] as const).map((t) => (
            <button
              key={t}
              onClick={() => setTab(t)}
              className={`font-display pb-0.5 transition ${
                tab === t ? "border-b-2 border-amber-300 text-amber-300" : "text-purple-200/60 hover:text-purple-100"
              }`}
            >
              {t}
            </button>
          ))}
        </div>
        <input
          type="text"
          placeholder={`${tab === "GLOBAL" ? "Global" : "Team"} chat...`}
          className="w-full rounded-md border border-white/10 bg-black/30 px-2.5 py-1.5 text-[11px] text-purple-50 placeholder-purple-200/40 outline-none focus:border-amber-300/50"
        />
      </div>

      {/* Icons bottom-right */}
      <div className="absolute right-59 bottom-3 z-10 flex gap-2">
        {[
          { icon: MessageSquare, badge: 1 },
          { icon: Bell },
          { icon: ImageIcon },
          { icon: Settings },
        ].map(({ icon: Icon, badge }, i) => (
          <button
            key={i}
            className="relative flex h-8 w-8 items-center justify-center rounded-full text-purple-100 transition hover:text-amber-300 sm:h-9 sm:w-9"
          >
            <Icon size={20} />
            {badge && (
              <span className="absolute -right-0.5 -top-0.5 flex h-3.5 w-3.5 items-center justify-center rounded-full bg-red-500 text-[8px] font-bold text-white">
                {badge}
              </span>
            )}
          </button>
        ))}
      </div>
    </footer>
  );
}
