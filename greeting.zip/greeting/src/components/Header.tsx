import { Home, Gamepad2, Coffee, CalendarCheck, ShoppingCart, UserCircle2 } from "lucide-react";
import EdgeCurve from "./EdgeCurve";

const navItems = [
  { label: "HOME", icon: Home, active: true },
  { label: "GAMES", icon: Gamepad2 },
  { label: "CAFE", icon: Coffee },
  { label: "BOOKING", icon: CalendarCheck },
  { label: "STORE", icon: ShoppingCart },
  { label: "PROFILE", icon: UserCircle2 },
];

export default function Header() {
  return (
    <header className="absolute top-0 left-0 z-30 w-full">
      <EdgeCurve position="top" />
      <div className="relative z-10 flex justify-center pt-4">
        <nav className="flex items-center gap-4 rounded-full px-4 py-1.5 sm:gap-5 sm:px-6">
          {navItems.map(({ label, icon: Icon, active }) => (
            <button
              key={label}
              className={`group flex flex-col items-center gap-0.5 text-[10px] font-semibold tracking-wide transition sm:text-xs ${
                active ? "text-amber-300" : "text-purple-100/70 hover:text-amber-200"
              }`}
            >
              <Icon
                size={15}
                strokeWidth={2}
                className={`transition ${active ? "drop-shadow-[0_0_6px_rgba(255,207,92,0.9)]" : "group-hover:drop-shadow-[0_0_6px_rgba(179,102,255,0.9)]"}`}
              />
              <span className="font-display hidden sm:inline text-[10px]">{label}</span>
              {active && <span className="mt-0.5 h-[2px] w-5 rounded-full bg-amber-300 shadow-[0_0_8px_rgba(255,207,92,1)]" />}
            </button>
          ))}
        </nav>
      </div>
    </header>
  );
}
